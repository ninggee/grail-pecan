package AVfix.locking;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sound.midi.SysexMessage;

import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.SootAgent4Fixing;

import AVfix.graph.Parameters;
import AVfix.icse.fixing.Domain;
import Drivers.Setup;
import Drivers.Utils;

import soot.Body;
import soot.G;
import soot.Local;
import soot.Modifier;
import soot.Pack;
import soot.PackManager;
import soot.PatchingChain;
import soot.RefType;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.VoidType;
import soot.jimple.Jimple;
import soot.jimple.JimpleBody;
import soot.jimple.ReturnStmt;
import soot.jimple.ReturnVoidStmt;
import soot.jimple.Stmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.internal.JReturnStmt;
import soot.jimple.internal.JReturnVoidStmt;
import soot.options.Options;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;

public class CopyOfXedgesLocker {
	// phase: function phase, not production level
	// ===========================
	// shared region for parameters, single-lock case, to be robust later,
	// [start,end, bb are already in the methdo parameters. 
	public static int throwableNum=0;
	
	

	
	   public static void fixUniquePoint(DirectedGraph ug, Xedge edge)
	   {
		   UnitGraph unitGraph = (UnitGraph) ug;
		   Body bb = unitGraph.getBody();
		   PatchingChain<Unit> units = bb.getUnits();
		   if(edge.getUniquePoint()!=null) throw new RuntimeException("why need fixing");
		   Stmt a = (Stmt)edge.getO1();
		   Stmt b = (Stmt)edge.getO2();
		   // note that one direct source at most! invariant
		   // the nop statement is sooner changed to monitoring statement
		   
		   if(a.branches()!=true)
		   {
			   // a->b directly, but b may have multiple remote sources.
			   Stmt x = Jimple.v().newNopStmt();// do nothing
			   units.insertAfter(x, a);// should not be insertBefore or insertBeforeNoDirect to b
			   edge.setUniquePoint(x);
		   }
		   else 
		   {			
			   boolean reallyBranch4you= true;
			   if(a instanceof JIfStmt)
			   {
				   JIfStmt aif = (JIfStmt)a;
				   if(aif.getTarget()!=b)
				   {
					   reallyBranch4you =false;
				   }				   
			   }
			   if(a instanceof JGotoStmt)
			   {
				   JGotoStmt agoto = (JGotoStmt)a;
				   if(agoto.getTarget()!=b)
				   {
					   reallyBranch4you =false;
				   }
			   }
			   if(!reallyBranch4you)
			   {
				   // just like no-branch at all. see the example, in the google sites.
				   // a->b directly, but b may have multiple remote sources.
				   Stmt x = Jimple.v().newNopStmt();// do nothing
				   units.insertAfter(x, a);// note that no redirecting, so that other remote sources do not pass hte exitmonitor 
				   edge.setUniquePoint(x);
			   }
			   else {
				  // yes, branch for you.
				// a is a remote source of b, b may have direct source and other remote sources.
				   // insert x before b without redirecting, all remote sources of b still goto b
				   // redirect a to x, so that it is the one passing x.
				   // for direct source of b, it may have to pass x which is unwanted.
				   // make it goto b then.
	               List<Stmt> preds = ug.getPredsOf(b);
				   
				   Stmt x = Jimple.v().newNopStmt();// all remote sources still goto b
				   units.insertBeforeNoRedirect(x, b);
				   
				   if(a instanceof JIfStmt)
				   {
					   JIfStmt aif = (JIfStmt)a;
					   aif.setTarget(x);// a is redirected to x now
				   }
				   else if (a instanceof JGotoStmt) {
					JGotoStmt agoto = (JGotoStmt)a;
					agoto.setTarget(x);
				   }
				   else {
					 throw new RuntimeException("what type can it be:" +a.getClass());
				    }
				  
				   
				   for(Stmt pred:preds)// for direct source
				   {
					   if(pred.branches()!=true)// Jif or goto would return true
					   {
						  Stmt newGotoStmt = Jimple.v().newGotoStmt(b);
						  units.insertAfter(newGotoStmt, pred); 
					   }
				   }
				   edge.setUniquePoint(x);
			   }
			   
			
		   }
		   try {
			   bb.validateLP();
		} catch (Exception e) {
		   //  System.out.println(bb);
		}
		  
	   }
	 
	 
		public static void lockWholeMethod(int bugId, CSMethod rCS) {
			
			   // need to be changed!!!!!!!!: 

		    	
		    	Body bb= rCS.getBb();
		    	SootMethod rm = bb.getMethod();	 
		    	
		    	if(!Domain.shouldInstrumentMethod(rm))
		    	{
		    		return;
		    	}
//		    	if(rm.getName().equals("replaceVal"))
//		    	{
//		    		System.out.println(rm.getActiveBody().toString());
//		    	}
		    	 
				 PatchingChain<Unit> unitsTmp = bb.getUnits();
				 Stmt firstNonTmp =bb.getFirstNonIdentityStmt();
				 if(firstNonTmp instanceof JReturnStmt || firstNonTmp instanceof JReturnVoidStmt)
				 {// the empty body incurs problems during the lock injection.
					 Stmt nop=Jimple.v().newNopStmt();
					 unitsTmp.insertBefore(nop, firstNonTmp);									 
				 }	
				 
				 
				 
		    	AfixInfoInAMethod localInfo =AfixInfo.getLocalInfo(bugId, rm.getSignature());
		    	if(localInfo==null) 
		    		throw new RuntimeException("how to continue?");
		    	
		    	Local localFromGlobal =localInfo.getLocalFromGlobal();
		    	
		    	
		        System.err.println("locking the whole method:" + rm.toString()  + "->|");
		        System.err.println();
				// intialize the global and get the local info. hoisted already

				//entermonitor, exitmonitor
		    	Set<Stmt> starts = new HashSet<Stmt>();
		    	//Unit firstNonId = bb.getFirstNonIdentityStmt();// newPrep is before the originalNoId, and now is the newNoID
				Stmt prep =localInfo.getNewPrep();
				Unit firstNon = localInfo.getOrigNonIdStmt();
		    	Stmt newEntermonitor = Jimple.v().newEnterMonitorStmt(localFromGlobal);
				PatchingChain<Unit> units = bb.getUnits();
				units.insertAfter(newEntermonitor, prep);// no redirect please, 
				starts.add((Stmt)firstNon);
		    	
				Set<Stmt> rets  = new HashSet<Stmt>();
				Iterator<Unit> it = bb.getUnits().iterator();
				while (it.hasNext()) {
					Unit unit = (Unit) it.next();
					if(unit instanceof ReturnVoidStmt || unit instanceof ReturnStmt)
					{
						rets.add((Stmt) unit );
					}
				}
				for(Stmt ret: rets)
				{
					standardGoToExit4MethodLevel( localInfo, (Stmt)ret, (JimpleBody)bb);
					exceptionalExit4MethodLevel(localInfo,starts, (Stmt)ret, (JimpleBody)bb);		
				}
				
				
				//bb.validateLP_nouse();
		
			
			
		}

		
	   public static void lockSingleNode(int bugId, CSMethod rCS) {		
		   // need to be changed!!!!!!!!: 

	    	Unit runit = rCS.getRunit();
	    	Body bb= rCS.getBb();
	    	SootMethod rm = bb.getMethod();	
	    	if(!Domain.shouldInstrumentMethod(rm))
	    	{
	    		return;
	    	}
//	    	if(rm.getName().equals("replaceVal"))
//	    	{
//	    		System.out.println(rm.getActiveBody().toString());
//	    	}
	    	
	    	AfixInfoInAMethod localInfo =AfixInfo.getLocalInfo(bugId, rm.getSignature());
	    	if(localInfo==null) 
	    		throw new RuntimeException("how to continue?");
	    	
	    	Local localFromGlobal =localInfo.getLocalFromGlobal();
	    	
	    	
	        System.err.println("locking:" + runit + " \n" +  "in " + rm.toString() + "->|");
	        System.err.println();
			// intialize the global and get the local info. hoisted already

			//entermonitor, exitmonitor
	    	Set<Stmt> starts = new HashSet<Stmt>();
	    	
			Stmt newEntermonitor = Jimple.v().newEnterMonitorStmt(localFromGlobal);
			PatchingChain<Unit> units = bb.getUnits();
			units.insertBefore(newEntermonitor, runit);// redirect please, all incoming goes through it!  			
			starts.add((Stmt)runit);
	    	
			if(runit.branches())
				 throw new RuntimeException("shared access, invocation and goto at one jimple???");
			standardGoToExit4singleNode( localInfo, (Stmt)runit, (JimpleBody)bb);
			exceptionalExit4singleNode(localInfo,starts, (Stmt)runit, (JimpleBody)bb);		
			bb.validateLP();
	}
	   
	   public static void lockXedgesOfPCM(int bugId, CSMethod pcCS)
	   {
	    	Body bb = pcCS.getBb();// yes, reuse many times!
	    	SootMethod pcm = bb.getMethod();
	    	if(!Domain.shouldInstrumentMethod(pcm))
	    	{
	    		return;
	    	}
	    	
	    	UnitGraph ugg = pcCS.getUg();
	    	Unit punit = pcCS.getPunit();
	    	Unit cunit = pcCS.getCunit();
	    	Set xedges = pcCS.getXedges();
	    
	    	
	        System.err.println("|->locking:" + punit + " \n" + cunit + "\n" + "in " + pcm.toString());
	        System.err.println();
	    	
	    	AfixInfoInAMethod localInfo =AfixInfo.getLocalInfo(bugId, pcm.getSignature());
	    	if(localInfo==null) 
	    		throw new RuntimeException("how to continue?");
	    	
	    	Local localFromGlobal =localInfo.getLocalFromGlobal();
	    	
			// intialize the global and get the local info. hoisted already

	    	//enter
	    	Set<Stmt> starts = new HashSet<Stmt>();
	    	for(Object x : xedges)
	    	{	    		
	    		Xedge xedge =(Xedge)x;	
	    		Unit uniquePoint = xedge.getUniquePoint();	    		
	    		if(xedge.isIncoming())
	    		{
	    			// entermonitor
	    			Stmt newEntermonitor = Jimple.v().newEnterMonitorStmt(localFromGlobal);
	    			PatchingChain<Unit> units = bb.getUnits();
	    			units.insertBeforeNoRedirect(newEntermonitor, uniquePoint);// simple, insert before uniquePoint by default	    			
	    			starts.add((Stmt)uniquePoint);
	    		}	    		
	    	}
	    	//exit
	    	for(Object x : xedges)
	    	{
	    		Xedge xedge =(Xedge)x;	
	    		Unit uniquePoint = xedge.getUniquePoint();
	    		if(!xedge.isIncoming())
	    		{
	    			// exitmonitor
	    			// insert after the nop, note that, nop may not be directly close to the external node.
	    			standardGoToExit4singleNode( localInfo, (Stmt)uniquePoint, (JimpleBody)bb);
	    			exceptionalExit4singleNode(localInfo,starts, (Stmt)uniquePoint, (JimpleBody)bb);	    			
	    		}		

	    	}
	    	
	    	bb.validateLP();
    	
	    
	   }

	    



		
		private static void addGlobalLock(AfixInfo buginfo) {
			if(Parameters.singleLock)
			{
				if(Parameters.globalLockObj!=null)
				{
					buginfo.setGlobalLockObj(Parameters.globalLockObj);
				}
				else {
					SootClass mainClassLockClass = buginfo.getMainClass_lockClass();
					int bugid = buginfo.getBugId();
					
					SootField globalLockObj = null;
					try {
						globalLockObj = mainClassLockClass.getFieldByName(
								"globalLockObj"+bugid);
						// field already exists
					} catch (RuntimeException re) {
						// field does not yet exist (or, as a pre-existing error, there is
						// more than one field by this name)
						globalLockObj = new SootField("globalLockObj"+bugid, RefType
								.v("java.lang.Object"), Modifier.STATIC | Modifier.PUBLIC);
						mainClassLockClass.addField(globalLockObj);
					}
					buginfo.setGlobalLockObj(globalLockObj);					
					initializeGlobalLockInClinit(buginfo);
					Parameters.globalLockObj = globalLockObj;
				}
			}
			else {
				SootClass mainClassLockClass = buginfo.getMainClass_lockClass();
				int bugid = buginfo.getBugId();
				
				SootField globalLockObj = null;
				try {
					globalLockObj = mainClassLockClass.getFieldByName(
							"globalLockObj"+bugid);
					// field already exists
				} catch (RuntimeException re) {
					// field does not yet exist (or, as a pre-existing error, there is
					// more than one field by this name)
					globalLockObj = new SootField("globalLockObj"+bugid, RefType
							.v("java.lang.Object"), Modifier.STATIC | Modifier.PUBLIC);
					mainClassLockClass.addField(globalLockObj);
				}
				buginfo.setGlobalLockObj(globalLockObj);
				initializeGlobalLockInClinit(buginfo);
			}
			
		}

		private static void initializeGlobalLockInClinit(AfixInfo buginfo) {
			// Either get or add the <clinit> method to the main class
			SootClass mainClass_lockClass=buginfo.getMainClass_lockClass();
			int bugid = buginfo.getBugId();
			SootField globalLockObj =buginfo.getGlobalLockObj();
			
			SootClass mainClass = mainClass_lockClass;
			SootMethod clinitMethod = null;
			JimpleBody clinitBody = null;
			Stmt firstStmt = null;
			boolean addingNewClinit = !mainClass.declaresMethod("void <clinit>()");
			if (addingNewClinit) {
				clinitMethod = new SootMethod("<clinit>", new ArrayList(), VoidType
						.v(), Modifier.PUBLIC | Modifier.STATIC);
				clinitBody = Jimple.v().newBody(clinitMethod);
				clinitMethod.setActiveBody(clinitBody);
				mainClass.addMethod(clinitMethod);
			} else {
				clinitMethod = mainClass.getMethod("void <clinit>()");
				if(!clinitMethod.hasActiveBody())
					clinitMethod.retrieveActiveBody();
				clinitBody = (JimpleBody) clinitMethod.getActiveBody();
				firstStmt = clinitBody.getFirstNonIdentityStmt();
			}
			PatchingChain<Unit> clinitUnits = clinitBody.getUnits();
			Local lockObj = Jimple.v().newLocal("localToGlobal_clinit"+bugid,
					RefType.v("java.lang.Object"));
			;

			// add local lock obj
			// addedLocalLockObj[i] = true;
			clinitBody.getLocals().add(lockObj);

			// assign new object to lock obj
			Stmt newStmt = Jimple.v().newAssignStmt(lockObj,
					Jimple.v().newNewExpr(RefType.v("java.lang.Object")));
			if (addingNewClinit)
				clinitUnits.add(newStmt);
			else
				clinitUnits.insertBeforeNoRedirect(newStmt, firstStmt);

			// initialize new object
			
			SootClass objectClass = Scene.v().loadClassAndSupport(
					"java.lang.Object");
			RefType type = RefType.v(objectClass);
			SootMethod initMethod = objectClass.getMethod("void <init>()");
			Stmt initStmt = Jimple.v().newInvokeStmt(
					Jimple.v().newSpecialInvokeExpr(lockObj, initMethod.makeRef(),
							Collections.EMPTY_LIST));
			if (addingNewClinit)
				clinitUnits.add(initStmt);
			else
				clinitUnits.insertBeforeNoRedirect(initStmt, firstStmt);

			// copy new object to global static lock object (for use by other fns)
			Stmt assignStmt = Jimple.v().newAssignStmt(
					Jimple.v().newStaticFieldRef(globalLockObj.makeRef()), lockObj);
			if (addingNewClinit)
				clinitUnits.add(assignStmt);
			else
				clinitUnits.insertBeforeNoRedirect(assignStmt, firstStmt);

			if (addingNewClinit) // finally
				clinitUnits.add(Jimple.v().newReturnVoidStmt());

		}

		private static void getGlobalLockInMethods(AfixInfo buginfo, SootMethod pcm , SootMethod rm) {
			HashMap<String, AfixInfoInAMethod> details =buginfo.getDetails();
			int bugId = buginfo.getBugId();
			SootField globalLockObj = buginfo.getGlobalLockObj();
			
			if(details==null) throw new RuntimeException();
			if(details.get(pcm.getSignature())==null)
			{
				AfixInfoInAMethod localbuginfo = new AfixInfoInAMethod();
				details.put(pcm.getSignature(), localbuginfo);// put the reference
				
				JimpleBody bb = (JimpleBody)pcm.getActiveBody();
				Local localFromGlobal = Jimple.v().newLocal("localFromGlobal_method"+bugId,
						RefType.v("java.lang.Object"));
				;
				
				bb.getLocals().add(localFromGlobal);
				localbuginfo.setLocalFromGlobal(localFromGlobal);
				AfixInfo.local2global.put(localFromGlobal, globalLockObj);
				
				Stmt newPrep = Jimple.v().newAssignStmt(localFromGlobal,
						Jimple.v().newStaticFieldRef(globalLockObj.makeRef()));
				PatchingChain<Unit> us = bb.getUnits();	
				Unit firstNon = bb.getFirstNonIdentityStmt();
				us.insertBeforeNoRedirect(newPrep, firstNon);// ? insertBefore <- this is
				localbuginfo.setNewPrep(newPrep);	
				localbuginfo.setOrigNonIdStmt(firstNon);
				//localbuginfo.set
			
				
			}
			
			if(details.get(rm.getSignature())==null)// it is possible that rm is the same as pcm, then returns non-null, no this branch!
			{
				AfixInfoInAMethod localbuginfo = new AfixInfoInAMethod();
				details.put(rm.getSignature(), localbuginfo);// put the reference
				
				JimpleBody bb = (JimpleBody)rm.getActiveBody();
				Local localFromGlobal = Jimple.v().newLocal("localFromGlobal_method"+bugId,
						RefType.v("java.lang.Object"));
				;

				bb.getLocals().add(localFromGlobal);
				localbuginfo.setLocalFromGlobal(localFromGlobal);
				AfixInfo.local2global.put(localFromGlobal, globalLockObj);
				
				
				Stmt newPrep = Jimple.v().newAssignStmt(localFromGlobal,
						Jimple.v().newStaticFieldRef(globalLockObj.makeRef()));
				PatchingChain<Unit> us = bb.getUnits();	
				Unit firstNon = bb.getFirstNonIdentityStmt();
				us.insertBeforeNoRedirect(newPrep, bb.getFirstNonIdentityStmt());// ? insertBefore <- this is
				localbuginfo.setNewPrep(newPrep);	
				localbuginfo.setOrigNonIdStmt(firstNon);
			}
														// the original version
		//	us.insertAfter(newPrep, bb.getFirstNonIdentityStmt());

		}

		// ========================================


		// ===========================================


// the end is actually the ret, goto ret, insert before ret
		private static void standardGoToExit4MethodLevel(AfixInfoInAMethod localInfo, Stmt end, JimpleBody bb) {
			// nop is placed directly before  b, 
			// but sometimes, the nop may be hoisted as a non-direct source of b.
			// still, nop is directly followed by a goto stateemtn
			// the following is correct, you can also instrument via injectAfter towards a.
			
			
			Stmt newPrep= localInfo.getNewPrep();
			Local localFromGlobal= localInfo.getLocalFromGlobal();
			
			PatchingChain<Unit> units = bb.getUnits();
			
			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertBeforeNoRedirect(tmp, end);

		
			
			Stmt newGotoExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
			units.insertBefore(newGotoExitmonitor, end); // can be NoRedirect, as there is nothing to rediract
				
			
			// them to monitorexit
			Stmt lastNewGotoEnd = Jimple.v().newGotoStmt(end);
			units.insertBeforeNoRedirect(lastNewGotoEnd, end);// carefully think about noReidrect and direct
			localInfo.setLastNewGotoEnd(lastNewGotoEnd);
			
			// Xedge is happy with both ways, before or end, as it is unique on the path
			// but the signle-node is only happy with the after-style!
//			PatchingChain<Unit> units = bb.getUnits();
//			Stmt after = (Stmt) units.getSuccOf(end);
//
//			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertBefore(tmp, after);
//
//		
//			
//			Stmt newGotoExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
//			units.insertBefore(newGotoExitmonitor, after); // can be NoRedirect, as there is nothing to rediract
//				
//			
//			// them to monitorexit
//			Stmt lastNewGotoEnd = Jimple.v().newGotoStmt(after);
//			units.insertBeforeNoRedirect(lastNewGotoEnd, after);
//			localInfo.setLastNewGotoEnd(lastNewGotoEnd);
			
			
			
		}
		
// you can goto after, but for ret end of method, you can not do that
		private static void standardGoToExit4singleNode(AfixInfoInAMethod localInfo, Stmt end, JimpleBody bb) {
			// nop is placed directly before  b, 
			// but sometimes, the nop may be hoisted as a non-direct source of b.
			// still, nop is directly followed by a goto stateemtn
			// the following is correct, you can also instrument via injectAfter towards a.
			
//			Stmt newPrep= localInfo.getNewPrep();
//			Local localFromGlobal= localInfo.getLocalFromGlobal();
//			
//			PatchingChain<Unit> units = bb.getUnits();
//			
//			
////			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
////			units.insertBeforeNoRedirect(tmp, end);
//
//		
//			
//			Stmt newGotoExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
//			units.insertBefore(newGotoExitmonitor, end); // can be NoRedirect, as there is nothing to rediract
//				
//			
//			// them to monitorexit
//			Stmt lastNewGotoEnd = Jimple.v().newGotoStmt(end);
//			units.insertBeforeNoRedirect(lastNewGotoEnd, end);// carefully think about noReidrect and direct
//			localInfo.setLastNewGotoEnd(lastNewGotoEnd);
			
			
			Stmt newPrep= localInfo.getNewPrep();
			Local localFromGlobal= localInfo.getLocalFromGlobal();
			
			PatchingChain<Unit> units = bb.getUnits();
			Stmt after = (Stmt) units.getSuccOf(end);

			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertAfter(tmp, end);

		
			
			Stmt newGotoExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
			units.insertAfter(newGotoExitmonitor, end); // can be NoRedirect, as there is nothing to rediract
				
			
			// them to monitorexit
			Stmt lastNewGotoEnd = Jimple.v().newGotoStmt(after);
			units.insertAfter(lastNewGotoEnd, newGotoExitmonitor);
			localInfo.setLastNewGotoEnd(lastNewGotoEnd);
			
			// Xedge is happy with both ways, before or end, as it is unique on the path
			
//			PatchingChain<Unit> units = bb.getUnits();
//			Stmt after = (Stmt) units.getSuccOf(end);
//
//			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertBefore(tmp, after);
//
//		
//			
//			Stmt newGotoExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
//			units.insertBefore(newGotoExitmonitor, after); // can be NoRedirect, as there is nothing to rediract
//				
//			
//			// them to monitorexit
//			Stmt lastNewGotoEnd = Jimple.v().newGotoStmt(after);
//			units.insertBeforeNoRedirect(lastNewGotoEnd, after);
//			localInfo.setLastNewGotoEnd(lastNewGotoEnd);
			
			
			
		}

		// the trap should be added in the front, as it is innermost or small.
		private static void exceptionalExit4singleNode( AfixInfoInAMethod localInfo, Set<Stmt> starts, Stmt end, JimpleBody bb) {
			Stmt lastNewGotoEnd= localInfo.getLastNewGotoEnd();
			Local localFromGlobal = localInfo.getLocalFromGlobal();
			Stmt newPrep= localInfo.getNewPrep();
			// get the lastEnd
			
			PatchingChain<Unit> units = bb.getUnits();
			Stmt lastEnd = null;
			if(lastNewGotoEnd!=null)
			{
				lastEnd = lastNewGotoEnd;
			}
			
			if( lastEnd == null )
				throw new RuntimeException("Lock Region has no ends!  Where should we put the exception handling???");

			//=====================
			// Add throwable
			Local throwableLocal = Jimple.v().newLocal("throwableLocal" + (throwableNum++), RefType.v("java.lang.Throwable"));
			bb.getLocals().add(throwableLocal);
			// Add stmts
			Stmt newCatch = Jimple.v().newIdentityStmt(throwableLocal, Jimple.v().newCaughtExceptionRef());
			
			Stmt newExceptionalExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
			units.insertAfter(newCatch, lastEnd);
			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertAfter(tmp, newCatch);
			
			units.insertAfter(newExceptionalExitmonitor, newCatch);// do not reuse the last exit monitor!, patchingchain will complain
			Stmt newThrow = Jimple.v().newThrowStmt(throwableLocal);
			units.insertAfter(newThrow, newExceptionalExitmonitor);
			// Add traps
			SootClass throwableClass = Scene.v().loadClassAndSupport("java.lang.Throwable");
			bb.getTraps().addFirst(Jimple.v().newTrap(throwableClass, newExceptionalExitmonitor, newThrow, newCatch));
			
			
			for(Stmt start: starts)// correct?
			{
				bb.getTraps().addFirst(Jimple.v().newTrap(throwableClass, start, lastEnd, newCatch));
			}
			

//			Utils.drawDirectedGraphNBody(new BriefUnitGraph(bb), bb,"random");

		}

		
		private static void exceptionalExit4MethodLevel( AfixInfoInAMethod localInfo, Set<Stmt> starts, Stmt end, JimpleBody bb) {
			Stmt lastNewGotoEnd= localInfo.getLastNewGotoEnd();
			Local localFromGlobal = localInfo.getLocalFromGlobal();
			Stmt newPrep= localInfo.getNewPrep();
			// get the lastEnd
			
			PatchingChain<Unit> units = bb.getUnits();
			Stmt lastEnd = null;
			if(lastNewGotoEnd!=null)
			{
				lastEnd = lastNewGotoEnd;
			}
			
			if( lastEnd == null )
				throw new RuntimeException("Lock Region has no ends!  Where should we put the exception handling???");

			//=====================
			// Add throwable
			Local throwableLocal = Jimple.v().newLocal("throwableLocal" + (throwableNum++), RefType.v("java.lang.Throwable"));
			bb.getLocals().add(throwableLocal);
			// Add stmts
			Stmt newCatch = Jimple.v().newIdentityStmt(throwableLocal, Jimple.v().newCaughtExceptionRef());
			
			Stmt newExceptionalExitmonitor = Jimple.v().newExitMonitorStmt(localFromGlobal);
			units.insertAfter(newCatch, lastEnd);
			
//			Stmt tmp = (Stmt) newPrep.clone();// newPrep is unique
//			units.insertAfter(tmp, newCatch);
			
			units.insertAfter(newExceptionalExitmonitor, newCatch);// do not reuse the last exit monitor!, patchingchain will complain
			Stmt newThrow = Jimple.v().newThrowStmt(throwableLocal);
			units.insertAfter(newThrow, newExceptionalExitmonitor);
			// Add traps
			SootClass throwableClass = Scene.v().loadClassAndSupport("java.lang.Throwable");
			
			// method is added outside incrementally, put at the end place of the traps
			for(Stmt start: starts)// correct?
			{
				bb.getTraps().addLast(Jimple.v().newTrap(throwableClass, start, lastEnd, newCatch));
			}
			
			bb.getTraps().addLast(Jimple.v().newTrap(throwableClass, newExceptionalExitmonitor, newThrow, newCatch));
			
//			Utils.drawDirectedGraphNBody(new BriefUnitGraph(bb), bb,"random");

		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// for single version, goto pecan_good.tar for he original details
		
		public static void main(String[] args) throws IOException {}

		// List entryPoints=EntryPoints.v().methodsOfApplicationClasses();
		// List mainEntries = new ArrayList();
		// for(int i=0;i< entryPoints.size(); i++)
		// {
		// if(entryPoints.get(i).toString().contains("main"))
		// {
		// mainEntries.add(entryPoints.get(i));
		// }
		// }
		//
		// soot.Scene.v().setEntryPoints(mainEntries); // process : app and its
		// reachable methods.




		public static void initializeGlock(int bugId, CSMethod pcCS, CSMethod rCS) {
			SootMethod pcm = pcCS.getBb().getMethod();
			SootMethod rm = rCS.getBb().getMethod();
			if(AfixInfo.bugs2info.get(bugId)==null)
			{
				String repClass = pcm.getDeclaringClass().getName();
				SootClass mainClass_lockClass = Scene.v().getSootClass(repClass);
				AfixInfo buginfo = new AfixInfo();		
				buginfo.setBugId(bugId);
				buginfo.setMainClass_lockClass(mainClass_lockClass);
				
				
				addGlobalLock(buginfo);
				
				getGlobalLockInMethods(buginfo,pcm, rm);// localFromGlobal, newPrep, lastGoto, origNonID
				
				AfixInfo.bugs2info.put(bugId, buginfo);

				
			}
						
		}


		public static void initializeGlock(int bugId,
				HashSet<SootMethod> methods) {
            SootMethod pcm =(SootMethod) methods.toArray()[0];
			if(AfixInfo.bugs2info.get(bugId)==null)
			{
				String repClass = pcm.getDeclaringClass().getName();
				SootClass mainClass_lockClass = Scene.v().getSootClass(repClass);
				AfixInfo buginfo = new AfixInfo();		
				buginfo.setBugId(bugId);
				buginfo.setMainClass_lockClass(mainClass_lockClass);
				
				
				addGlobalLock(buginfo);
				
				getGlobalLockInMethods(buginfo,methods);// localFromGlobal, newPrep, lastGoto, origNonID
				
				AfixInfo.bugs2info.put(bugId, buginfo);

				
			}
						
		
			
		}


		private static void getGlobalLockInMethods(AfixInfo buginfo,
				HashSet<SootMethod> methods) {

			HashMap<String, AfixInfoInAMethod> details =buginfo.getDetails();
			int bugId = buginfo.getBugId();
			SootField globalLockObj = buginfo.getGlobalLockObj();
			
			if(details==null) throw new RuntimeException();
			for(SootMethod pcm : methods)
			{
				if(details.get(pcm.getSignature())==null)
				{
					AfixInfoInAMethod localbuginfo = new AfixInfoInAMethod();
					details.put(pcm.getSignature(), localbuginfo);// put the reference
					
					JimpleBody bb = (JimpleBody)pcm.getActiveBody();
					Local localFromGlobal = Jimple.v().newLocal("localFromGlobal_method"+bugId,
							RefType.v("java.lang.Object"));
					;
					
					bb.getLocals().add(localFromGlobal);
					Stmt newPrep = Jimple.v().newAssignStmt(localFromGlobal,
							Jimple.v().newStaticFieldRef(globalLockObj.makeRef()));
					localbuginfo.setLocalFromGlobal(localFromGlobal);
					AfixInfo.local2global.put(localFromGlobal, globalLockObj);
					
					
					PatchingChain<Unit> us = bb.getUnits();	
					Unit firstNon = bb.getFirstNonIdentityStmt();
					us.insertBeforeNoRedirect(newPrep, firstNon);// ? insertBefore <- this is
					localbuginfo.setNewPrep(newPrep);	
					localbuginfo.setOrigNonIdStmt(firstNon);
					//localbuginfo.set
				
					
				}
			}
																	// the original version
		//	us.insertAfter(newPrep, bb.getFirstNonIdentityStmt());

		
			
		}


		public static void lockSingleUnit(int bugId, SootMethod rm, Unit runit) {
			
			   // need to be changed!!!!!!!!: 

	    	if(!Domain.shouldInstrumentMethod(rm))
	    	{
	    		return;
	    	}
		    	Body bb= rm.getActiveBody();
		    
		    	
		    	AfixInfoInAMethod localInfo =AfixInfo.getLocalInfo(bugId, rm.getSignature());
		    	if(localInfo==null) 
		    		throw new RuntimeException("how to continue?");
		    	
		    	Local localFromGlobal =localInfo.getLocalFromGlobal();
		    	
		    	
		        System.err.println("locking:" + runit + " \n" +  "in " + rm.toString() + "->|");
		        System.err.println();
				// intialize the global and get the local info. hoisted already

				//entermonitor, exitmonitor
		    	Set<Stmt> starts = new HashSet<Stmt>();
		    	
				Stmt newEntermonitor = Jimple.v().newEnterMonitorStmt(localFromGlobal);
				PatchingChain<Unit> units = bb.getUnits();
				units.insertBefore(newEntermonitor, runit);// redirect please, all incoming goes through it!  			
				starts.add((Stmt)runit);
		    	
				if(runit.branches())
					 throw new RuntimeException("shared access, invocation and goto at one jimple???");
				standardGoToExit4singleNode( localInfo, (Stmt)runit, (JimpleBody)bb);
				exceptionalExit4singleNode(localInfo,starts, (Stmt)runit, (JimpleBody)bb);		
				bb.validateLP();
		
			
		}


		public static void lockWholeMethod(int bugId, SootMethod rm) {

			
			   // need to be changed!!!!!!!!: 

	    	if(!Domain.shouldInstrumentMethod(rm))
	    	{
	    		return;
	    	}
		    	Body bb= rm.getActiveBody();
		    	 
				 PatchingChain<Unit> unitsTmp = bb.getUnits();
				 Stmt firstNonTmp =bb.getFirstNonIdentityStmt();
				 if(firstNonTmp instanceof JReturnStmt || firstNonTmp instanceof JReturnVoidStmt)
				 {// the empty body incurs problems during the lock injection.
					 Stmt nop=Jimple.v().newNopStmt();
					 unitsTmp.insertBefore(nop, firstNonTmp);									 
				 }	
				 
				 
				 
		    	AfixInfoInAMethod localInfo =AfixInfo.getLocalInfo(bugId, rm.getSignature());
		    	if(localInfo==null) 
		    		throw new RuntimeException("how to continue?");
		    	
		    	Local localFromGlobal =localInfo.getLocalFromGlobal();
		    	
		    	
		        System.err.println("locking the whole method:" + rm.toString()  + "->|");
		        System.err.println();
				// intialize the global and get the local info. hoisted already

				//entermonitor, exitmonitor
		    	Set<Stmt> starts = new HashSet<Stmt>();
		    	//Unit firstNonId = bb.getFirstNonIdentityStmt();// newPrep is before the originalNoId, and now is the newNoID
				Stmt prep =localInfo.getNewPrep();
				Unit firstNon = localInfo.getOrigNonIdStmt();
		    	Stmt newEntermonitor = Jimple.v().newEnterMonitorStmt(localFromGlobal);
				PatchingChain<Unit> units = bb.getUnits();
				units.insertAfter(newEntermonitor, prep);// no redirect please, 
				starts.add((Stmt)firstNon);
		    	
				Set<Stmt> rets  = new HashSet<Stmt>();
				Iterator<Unit> it = bb.getUnits().iterator();
				while (it.hasNext()) {
					Unit unit = (Unit) it.next();
					if(unit instanceof ReturnVoidStmt || unit instanceof ReturnStmt)
					{
						rets.add((Stmt) unit );
					}
				}
				for(Stmt ret: rets)
				{
					standardGoToExit4MethodLevel( localInfo, (Stmt)ret, (JimpleBody)bb);
					exceptionalExit4MethodLevel(localInfo,starts, (Stmt)ret, (JimpleBody)bb);		
				}
				
				
				//bb.validateLP_nouse();
		
			
			
		
			
		}


		
		
	    
}
