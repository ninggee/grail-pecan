package AVfix.edge.abstractclass;

import org.jgrapht.graph.DefaultEdge;

public abstract class ControlEdge  extends DefaultEdge{

}
