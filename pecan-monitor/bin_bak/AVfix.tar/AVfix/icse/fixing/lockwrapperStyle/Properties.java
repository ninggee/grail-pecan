package AVfix.icse.fixing.lockwrapperStyle;

import soot.SootField;

public class Properties {
  public static boolean rInPC_reduct_opt = false;// it is not correct, r in PC, you still need to protect pc,right?
  public static boolean subsume_removal_opt = true;
  public static boolean merge_of_jin_opt = true;

  
  public static boolean removeSynch = false;
   public static boolean removeWait = false;
   protected static boolean report = true;;
   
   
  public static String localizedPrefix = "localizedLock_";
  public static String enforceClass  = "enforceRefreshClassLP";
	
	public static boolean singleLock = false;
	public static SootField globalLockObj =null;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
