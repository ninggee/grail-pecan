package AVfix.node.abstractclass;

import java.util.List;

import edu.hkust.clap.datastructure.StackTraceElement_lpxz;

public abstract class Statement {

    List<StackTraceElement_lpxz> stes ;
    public List<StackTraceElement_lpxz> getStes() {
		return stes;
	}

	public void setStes(List<StackTraceElement_lpxz> stes) {
		this.stes = stes;
	}

	public String getMsig() {
		return msig;
	}

	public void setMsig(String msig) {
		this.msig = msig;
	}

	String msig ;
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
