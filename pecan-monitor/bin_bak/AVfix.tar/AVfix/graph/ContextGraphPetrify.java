package AVfix.graph;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import AVfix.edge.CallEdge;
import AVfix.edge.LocalEdge;
import AVfix.edge.ReturnEdge;
import AVfix.edge.abstractclass.ControlEdge;
import AVfix.node.EntryStatement;
import AVfix.node.TStatement;
import AVfix.node.abstractclass.Statement;

public class ContextGraphPetrify {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void petrify(ContextGraph csGraph) {
		HashSet<ContextGraphMethod> roots =csGraph.getThreadRoots();
		for(ContextGraphMethod root : roots)
		{
			EntryStatement entry =root.getEntry();
			// begin dfs now
			petrify0(csGraph, entry);			
		}
		
		
	}

	public static Stack systemStack = new Stack();
    public static Set visited = new HashSet();   

    
	private static void petrify0(ContextGraph csGraph, EntryStatement entry) {

        systemStack.clear();
        visited.clear();
		systemStack.push(entry);	
    	if(!visited.contains(entry))
    	{
    	    visited.add(entry);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =csGraph.getAllSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	// here, visist the edge, do not visit inside the following branch, it would miss some unvisited edges with the target nodes  visited.
		    	
		    	petrify_an_edge(csGraph, (Statement)pop, (Statement) child);// done
		    	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}	
	}

	private static void petrify_an_edge(ContextGraph csGraph, Statement pop,
			Statement child) {
		// add newtransition to the graph first
		TStatement newone = new TStatement();
		csGraph.coreG.addVertex(newone);
		ControlEdge edge =csGraph.coreG.getEdge(pop, child);
		if(edge instanceof LocalEdge)
		{
			csGraph.coreG.addEdge_edgetype_lpxz(pop, newone, LocalEdge.class);
			csGraph.coreG.addEdge_edgetype_lpxz(newone, child, LocalEdge.class);
			csGraph.coreG.removeEdge(pop, child);
		}else if (edge instanceof CallEdge) {
			csGraph.coreG.addEdge_edgetype_lpxz(pop, newone, CallEdge.class);
			csGraph.coreG.addEdge_edgetype_lpxz(newone, child, CallEdge.class);
			csGraph.coreG.removeEdge(pop, child);
		}
		else if (edge instanceof ReturnEdge) {
			csGraph.coreG.addEdge_edgetype_lpxz(pop, newone, ReturnEdge.class);
			csGraph.coreG.addEdge_edgetype_lpxz(newone, child, ReturnEdge.class);
			csGraph.coreG.removeEdge(pop, child);
		}
		else {
			throw new RuntimeException("impossible type..");
		}
	
		
		HashSet<Statement> places = csGraph.getPlaces();
		HashSet<TStatement> transitions = csGraph.getTransitions();
		places.add(pop); places.add(child);		
		transitions.add(newone);	
	}

}
