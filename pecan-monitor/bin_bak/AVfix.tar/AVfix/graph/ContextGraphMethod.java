package AVfix.graph;

import java.util.HashMap;
import java.util.List;

import soot.Body;
import soot.Unit;

import edu.hkust.clap.datastructure.StackTraceElement_lpxz;

import AVfix.node.EntryStatement;
import AVfix.node.ExitStatement;
import AVfix.node.abstractclass.Statement;

public class ContextGraphMethod {
	// guan neng tuan
	// it is an organ of the graph
	
	
	public HashMap<Unit, Integer> u2LineNO ;
	
	public HashMap<Unit, Integer> getU2LineNO() {
		return u2LineNO;
	}
	public void setU2LineNO(HashMap<Unit, Integer> u2LineNO) {
		this.u2LineNO = u2LineNO;
	}

	


	public String classname ;
	public String methodName; 
	
	
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	
	
	
	public EntryStatement entry ;

	public ExitStatement exit ;

	public Body bb ;
	public HashMap<Unit, Statement> u2S ;
	
	public EntryStatement getEntry() {
		return entry;
	}
	public void setEntry(EntryStatement entry) {
		this.entry = entry;
	}
	public ExitStatement getExit() {
		return exit;
	}
	public void setExit(ExitStatement exit) {
		this.exit = exit;
	}

	public Body getBb() {
		return bb;
	}
	public void setBb(Body bb) {
		this.bb = bb;
	}
	public HashMap<Unit, Statement> getU2S() {
		return u2S;
	}
	public void setU2S(HashMap<Unit, Statement> u2s) {
		u2S = u2s;
	}

	 List<StackTraceElement_lpxz> stes ;
	    public List<StackTraceElement_lpxz> getStes() {
			return stes;
		}

		public void setStes(List<StackTraceElement_lpxz> stes) {
			this.stes = stes;
		}
		
}
