package AVfix.icse.fixing;

import soot.SootMethod;

public class Domain {
// do not touch such methods, such as the spin lock implementation
	// e.g., Clock.synchronize, a never-stop runner..
	static String[] newMethodBlackList4Fixing = {
		"org.exolab.jms.common.uuid.Clock.synchronize"
	};
	
	
	static String[] newClassBlackList4Fixing = 
	{
		"EDU.oswego.cs.dl.util.concurrent",
		"org.exolab.jms.common.uuid.Clock",
		"org.exolab.jms.net.multiplexer",
		"org.exolab.jms.net.connector.ManagedConnectionHandle"
	};
	public static boolean shouldInstrumentMethod(SootMethod sootMethod) {
		if(!Domain.shouldInstruThis_ClassFilter(sootMethod.getDeclaringClass().getName()))
			return false;
		if(!Domain.shouldInstruThis_ClassFilter(sootMethod.getDeclaringClass().getName(), newClassBlackList4Fixing))
		    return false;
		
		String fullname = sootMethod.getDeclaringClass().getName()  + "." + sootMethod.getName();
		if(!shouldInstruThis_MethodFilter(fullname, newMethodBlackList4Fixing))
			return false;
		
		if(!sootMethod.hasActiveBody())
			return false;
		if(sootMethod.getName().equals(SootMethod.constructorName)
				||sootMethod.getName().equals(SootMethod.staticInitializerName))
		{
			return false;
		}
		
		return true;
	}

	public static boolean shouldInstruThis_ClassFilter(String scname)
	{
		for(int k=0;k<unInstruClasses.length;k++)
		{
			if(scname.startsWith(unInstruClasses[k]))
			{
				return false;
			}
		}
		
		return true;
	}

	public static boolean shouldInstruThis_ClassFilter(String scname, String[] args)
	{
		for(int k=0;k<args.length;k++)
		{
			if(scname.startsWith(args[k]))
			{
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean shouldInstruThis_MethodFilter(String scname, String[] args)
	{
		for(int k=0;k<args.length;k++)
		{
			if(scname.startsWith(args[k]))
			{
				return false;
			}
		}
		
		return true;
	}

	// copy from pecan-transformer, make sure the consistency, do not change at  a single side
	public static String[] unInstruClasses = {
		    "org.apache.log4j.",
			"jrockit.",
			"java.",
			"javax.",
			"xjava.",
			"COM.",
			"com.",
			"cryptix.",
			"sun.",
			"sunw.",
			"junit.",
			"org.junit.",
			"org.xmlpull.",
			"edu.hkust.clap.",
			// the following are copied frpm the transforming options. (commandLine)
			"org.apache.commons.logging.",// annoying, ban it
			"org.apache.xalan.",
			"org.apache.xpath.",
			"org.springframework.",
			"org.jboss.",
			"jrockit.",
			"edu.",				
			"checkers.",
			"org.codehaus.spice.jndikit.",
			"EDU.oswego.cs.dl.util.concurrent.WaiterPreferenceSemaphore",
			"soot.",
			"aTSE.",
			"pldi.",
			"popl.", 
			"beaver.",
			"org.jgrapht",
			"ca.pfv.spmf.","japa.parser.", "polyglot."
			
			// org.w3c. is the including option			
	};
	

}
