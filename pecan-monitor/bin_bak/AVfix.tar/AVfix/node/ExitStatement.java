package AVfix.node;

import AVfix.node.abstractclass.Statement;
import AVfix.node.abstractclass.SuperficialStatement;

public class ExitStatement extends SuperficialStatement{

}
