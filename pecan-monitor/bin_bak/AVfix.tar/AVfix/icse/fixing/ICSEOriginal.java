package AVfix.icse.fixing;



import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import org.jgrapht.alg.CycleDetector;
import org.jgrapht.alg.StrongConnectivityInspector;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DirectedPseudograph;

import com.sun.net.httpserver.Filter;

import pldi.locking.CriticalSection;
import pldi.locking.MethodLocker;
import pldi.locking.SynchronizedRegionFinder;
import pldi.locking.SynchronizedRegionFlowPair;

import soot.AnySubType;
import soot.Body;
import soot.EntryPoints;
import soot.G;
import soot.Local;
import soot.Modifier;
import soot.PackManager;
import soot.PatchingChain;
import soot.PointsToAnalysis;
import soot.PointsToSet;
import soot.RefType;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AssignStmt;
import soot.jimple.EnterMonitorStmt;
import soot.jimple.ExitMonitorStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.Jimple;
import soot.jimple.JimpleBody;
import soot.jimple.Stmt;
import soot.jimple.StringConstant;
import soot.jimple.internal.JReturnStmt;
import soot.jimple.internal.JReturnVoidStmt;
import soot.jimple.spark.pag.Node;
import soot.jimple.spark.sets.P2SetVisitor;
import soot.jimple.spark.sets.PointsToSetInternal;
import soot.jimple.toolkits.thread.synchronizationLP.DeadlockAvoidanceEdge;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.pdg.EnhancedUnitGraph;
import soot.toolkits.scalar.FlowSet;
import soot.util.Chain;



import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;
import edu.hkust.clap.organize.SaveLoad;
import edu.hkust.clap.organize.SootAgent4Fixing;




import AVfix.debug.InjectChocalate;
import AVfix.edge.LocalEdge;
import AVfix.graph.ContextGraph;
import AVfix.graph.ContextGraphMethod;
import AVfix.icse.fixing.opt.Merge;
import AVfix.icse.fixing.opt.MergedBug;
import AVfix.icse.fixing.opt.MergedBugComponent;
import AVfix.icse.fixing.opt.Reduction;
import AVfix.locking.AfixInfo;

import AVfix.locking.Xedge;
import AVfix.locking.XedgesLocker;
import AVfix.node.EntryStatement;
import AVfix.node.ExitStatement;
import AVfix.node.InvokeBeginStatement;
import AVfix.node.InvokeEndStatement;
import AVfix.node.abstractclass.Statement;
import AVfix.unitgraph.LocalUnitGraphReachable;
import Drivers.Utils;

public class ICSEOriginal {

	
	public static void main(String[] args)
	{
		 System.out.println("===========================================");
		 System.out.println("Original:");
		// do not need to set the option, as no locks are added
		Object object2 = SaveLoad.load(SaveLoad.default_filename);
		 List list2  =(List)object2;// CSMethodPair List		
		 System.err.println("set the main class and the analyzedFolder in SootAgent4Fixing");
		 ICSEOriginal.fix(list2, null);		
//		//r.*.<org.exolab.jms.net.registry.Registry: org.exolab.jms.net.proxy.Proxy lookupjava.lang.String>()
//		//r13.<org.exolab.jms.net.registry.Registry: org.exolab.jms.net.proxy.Proxy lookupjava.lang.String>()
//		System.out.println(Pattern.matches("@",
//		"@"));
	}
	// batch style, do not fix one by one
	
	public static void fix(List list, ContextGraph csGraph) {			
		SootAgent4Fixing.sootLoadNecessary(list, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/origSootOutput");
		//setUnitRef_Xedges_Phase(list);
		//list =Reduction.reduce(list);// similar to JIn's removal
		
		//final List newList = list;
		//System.err.println(newList.size());	
	
		 PackManager.v().getPack("wjtp").add(new Transform("wjtp.transformer1", new SceneTransformer() {
			
			@Override
			protected void internalTransform(String phaseName, Map options) {
				Set<CriticalSection> oldHealthyCSs =getCriticalSections();
				System.err.println("bad guys before applying locking:" + badguys);
				badguys =0;// reset
				
//				long start1 = System.currentTimeMillis();				
//				applyLocking_phase(newList);					
//				long end1  = System.currentTimeMillis();
//				long fixav = (end1 -start1);
//				System.err.println("time of fixing av:" + fixav);			
//				 
//				
//				 // true branch is not fully tested, although the idea is simple
//			    // we take into consideration of the inst->sootField relation, 
//			    // just put the inst into the before set, and then, before-> non-Reentrant sootField is the order
//				long start2 = System.currentTimeMillis();
//			    deadlockAvoidance(ContextGraph.getContextGraph(), false);	// do not include the instancelokc, false
//			    long end2 = System.currentTimeMillis();
//			    long fixDeadlock = (end2-start2);
//			    System.err.println("time of fixing deadlock: " + fixDeadlock);
			    
			   SootMethod SM = Scene.v().getMainMethod();
			   InjectChocalate.addTimeReport(SM);			    
			   // ===========trick: remove all synchronizations!after the fixing!
			   if(Properties.removeSynch)
			   {
				   for(CriticalSection cs : oldHealthyCSs)
				   {
					   change2locallock(cs, Properties.removeWait);// if exceptionalend is null now, throw exception!
				   }
				   removalSynchronziedWord(Properties.removeWait);
			   }
			   if(Properties.report)
			   {
				   addReport2AllHealthyCSs_nonLocalized();// include the newly created
			   }
				
			}


			
			
			private void addReport2AllHealthyCSs_nonLocalized() {
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {			
						
						SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {
							if(sootMethod.isSynchronized())// avoid the deadlocks, later on, fix the syncFinder bug and do more solid!
							{
								//if(!containsWaitNotify(sootMethod))
								{
									 sootMethod.setModifiers(sootMethod.getModifiers() & ~Modifier.SYNCHRONIZED);
									 MethodLocker.addlock(sootMethod);
								}
								
							}
							
							InjectChocalate.addLockReport4HealthyCS_ignoreNullExcEnd(sootMethod);	
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
				
			}




			private void removalSynchronziedWord(boolean removeWait) {
				
				Set<CriticalSection> ret = new HashSet<CriticalSection>();
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {
							if(sootMethod.isSynchronized())// avoid the deadlocks, later on, fix the syncFinder bug and do more solid!
							{
								if(!removeWait)
									continue;
								if(!containsWaitNotify(sootMethod))
								{
									 sootMethod.setModifiers(sootMethod.getModifiers() & ~Modifier.SYNCHRONIZED);
										
								}
								if(removeWait)
								{
									removeWaits(sootMethod.getActiveBody());
								}
								 //MethodLocker.addlock(sootMethod);
							}
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
			   
			
			}




			public  int serialNo = 0;
			private void change2locallock(CriticalSection cSection, boolean removeWait)
			{
				SootMethod method = cSection.method;
				Body b = method.retrieveActiveBody();
				UnitGraph  eug = new EnhancedUnitGraph(
						b);

				// if you do not remove wait, do not touch the contianing cs too
				// if you remove wait, ok, remove them
				
				if(!removeWait)// 
				{
					if(cSection.waits!=null && cSection.waits.size()!=0)
					{
						return;// complex, do not touch it
					}
					if(cSection.notifys!=null && cSection.notifys.size()!=0)
					{
						return;
					}
				}
				
				
				Chain units = b.getUnits();
				Unit lastUnit = (Unit) units.getLast();

			
		    	Stmt prep = cSection.prepStmt;
		    	
		    	
				Local lockObj = Jimple.v().newLocal(Properties.localizedPrefix + (serialNo++),
						RefType.v("java.lang.Object"));
				;
	
				// add local lock obj
				// addedLocalLockObj[i] = true;
				b.getLocals().add(lockObj);
	
				// assign new object to lock obj
				Stmt newStmt = Jimple.v().newAssignStmt(lockObj,
						Jimple.v().newNewExpr(RefType.v("java.lang.Object")));
				

						// initialize new object
						
				SootClass objectClass = Scene.v().loadClassAndSupport(
						"java.lang.Object");
				RefType type = RefType.v(objectClass);
				SootMethod initMethod = objectClass.getMethod("void <init>()");
				Stmt initStmt = Jimple.v().newInvokeStmt(
						Jimple.v().newSpecialInvokeExpr(lockObj, initMethod.makeRef(),
								Collections.EMPTY_LIST));
				
				units.insertAfter(newStmt, prep);
				units.insertAfter(initStmt,newStmt);
				
				EnterMonitorStmt enter = (EnterMonitorStmt)cSection.entermonitor;
				enter.setOp(lockObj);
				Set<ExitMonitorStmt> exits =cSection.getExitMonitors();
				for(ExitMonitorStmt exit : exits)
				{
					exit.setOp(lockObj);
				}  	//System.out.println("lock:" + cSection.origLock + " "+cSection.prepStmt);
				    	
				
				if(removeWait)
				{
					removeWaits(b);
				}
				   
				
				b.validateLP_nouse();
		
				
				
				
			
				
			}




			private void removeWaits(Body b) {
				// it does not matter if this body is clearly for multiple times
				PatchingChain<Unit> units =b.getUnits();
				HashSet<Unit > toremove = new HashSet<Unit>();
				for(Unit unit : units)
				{
					Stmt stmt = (Stmt) unit;
					if(stmt.containsInvokeExpr())
					{
						if(stmt.getInvokeExpr().getMethod().getName().equals("wait")
					  || stmt.getInvokeExpr().getMethod().getName().equals("notify")
					  || stmt.getInvokeExpr().getMethod().getName().equals("notifyAll"))
						{
							//System.err.println("to remove:" + stmt);
							toremove.add(stmt);
						}
					}
				}
				for(Unit tor : toremove)
				{
					units.removeAll(toremove);
				}
			
				//System.err.println(b.toString());
				
			}




			private Set<CriticalSection> getCriticalSections() {	
				Set<CriticalSection> ret = new HashSet<CriticalSection>();
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {							
							List<CriticalSection> css =getCriticalSections(sootMethod);
							for(CriticalSection cs : css)
							{
								if(isHealthy(cs))
								{
									ret.add(cs);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
			    return ret;
			}



            int badguys =0;
			private boolean isHealthy(CriticalSection cs) {
				if(cs.entermonitor!=null && cs.origLock !=null && cs.prepStmt!=null
						&& cs.exceptionalEnd!=null)
					return true; 
				badguys ++;
				return false;
			}




			private boolean containsWaitNotify(SootMethod sootMethod) {
			   if(sootMethod.hasActiveBody())
			   {
				   Iterator<Unit> it =sootMethod.getActiveBody().getUnits().iterator();
			       while (it.hasNext()) {
					Stmt unit = (Stmt) it.next();
					if(unit.containsInvokeExpr())
					{
						String mName =unit.getInvokeExpr().getMethod().getName();
					    if(mName.equals("wait") || mName.equals("notify")
					    		||mName.equals("notifyAll")
					    		||mName.equals("join")
					    		||mName.equals("start"))
					    	return true;
					}
					
				}
			   }
			   return false;
			}




			////\======================================================================
			public  void deadlockAvoidance(ContextGraph csGraph, boolean instLock) {
				HashSet<ContextGraphMethod> roots =csGraph.getThreadRoots();
				DirectedPseudograph ddg = new DirectedPseudograph(DefaultEdge.class);
				for(ContextGraphMethod root : roots)
				{
					EntryStatement entry =root.getEntry();
					// begin dfs now
					deadlockAvoidance0(csGraph, entry,ddg, instLock);			
				}
				StrongConnectivityInspector sci = new StrongConnectivityInspector(ddg);
				List<Set> sccList= sci.stronglyConnectedSets();// ntoe there, we have the scc, not the cycle, scc is more strong than cycle
				//after collapse, there is only DAG

				// play with it,
				//substitute all the locks in the cycle to one rep		
				HashMap subtable =construct_substitute_table(sccList);
				


				    
				    
				for(ContextGraphMethod root : roots)
				{
					EntryStatement entry =root.getEntry();
					// begin dfs now
					deadlockSubstitute(csGraph, entry, subtable, instLock);			
				}
			}
			
			
			

			private void deadlockSubstitute(ContextGraph csGraph,
					EntryStatement entry, HashMap subtable, boolean instLock) {				
		        queueingStack.clear();
		        visited.clear();
				queueingStack.push(entry);	
		    	if(!visited.contains(entry))
		    	{
		    	    visited.add(entry);
		    	}
			
				while(!queueingStack.isEmpty())
				{
				    Object pop =queueingStack.pop();
				    if(pop instanceof EntryStatement)// just consider the first popping, it is enough to visit the ndoes
				    {
				    	entry_subtitute_lock(((EntryStatement) pop).getMsig(), subtable, instLock);
				    }    
				    
				    List children =csGraph.getAllSuccs(pop);// ug.getSuccsOf(pop);
				    for(int i = children.size()-1; i>=0; i--)
				    {
				    	Object child = children.get(i);	
				     	
				    	if(!visited.contains(child))
				    	{
				    	    visited.add(child);
				    		queueingStack.push(child);				    		
				    	}
				    }
				    
				}	
			
				
				
			}

			private void entry_subtitute_lock(String msig, HashMap subtable, boolean instLock) {
				 // a cycle may contain only inst locks? cycles may be weird, only consider x-> sf -> x, yes, simple edition is enough
				   
				SootMethod method = Scene.v().getMethod(msig);
				Body b = method.getActiveBody();
			
				List<CriticalSection> csL = getCriticalSections(method);
				PatchingChain<Unit> units = b.getUnits();
				
				Set<SootField> origs = new HashSet<SootField>();
				for(CriticalSection cs :csL)
				{
					Local l =(Local)cs.origLock;
					if(getTheRep(l,subtable)!=null)
					{

						SootField theRep = (SootField) getTheRep(l, subtable);
						Stmt prep = cs.prepStmt;
						String thesubedRepMonitor = "localFromGlobal_method_sub_"+ theRep.getName();// only need one lock for the  global subsittuted from dfifferent local loks.
						Stmt newPrep =search4Prep(b,thesubedRepMonitor);// use the name,yes
						Local newMonitor =null;
						if(newPrep==null)
						{
					    	newMonitor = Jimple.v().newLocal(thesubedRepMonitor, RefType.v("java.lang.Object"));//
							if(!b.getLocals().contains(newMonitor))
							{
								b.getLocals().add(newMonitor);
							}										
							newPrep = Jimple.v().newAssignStmt(newMonitor,
									Jimple.v().newStaticFieldRef(theRep.makeRef()));
							units.insertAfter(newPrep, prep);
						}
						else {
							newMonitor = (Local)((AssignStmt) newPrep).getLeftOp();
						}								
						
						
						System.err.println("substituting the monitor to: " + thesubedRepMonitor);
						EnterMonitorStmt enter = (EnterMonitorStmt)cs.entermonitor;
						enter.setOp(newMonitor);
						Set<ExitMonitorStmt> exits =cs.getExitMonitors();
						for(ExitMonitorStmt exit : exits)
						{
							exit.setOp(newMonitor);
						}				
					}
													
				}			
			}

			private Object getTheRep(Local l, HashMap subtable) {
				if(l.getName().startsWith("localFromGlobal"))
				{
					SootField sf = AfixInfo.getGlobalwithLocal(l);	
					return subtable.get(sf);
				}	
				else {
					Set set =getPoint2S(l);
				    for(Object o : set)
				    {
				    	if(subtable.get(o)!=null)// each item in the point to set is symmetric to the sootfield in cycle formation!
				    	{
				    		return subtable.get(o);
				    	}
				    }
				    return null;
				}
				
				
			}

			private Stmt search4Prep(Body b, String thesubedRepMonitor){
				Iterator<Unit> iterator=b.getUnits().iterator();
				while (iterator.hasNext()) {
					Unit unit = (Unit) iterator.next();
					if(unit instanceof AssignStmt)
					{
						Local left =(Local)((AssignStmt) unit).getLeftOp();
						if(left.getName().equals(thesubedRepMonitor))
						{
							return (Stmt)unit;
						}
					}
					
				}
				return null;
			}			
			

			private HashMap construct_substitute_table(List<Set> sccList) {
				HashMap toretHashMap = new HashMap();
				for(Set scc:sccList)
				{
				    if(scc.size()<2) continue; // trivial case
					Object rep =getASootField(scc);
					if(rep ==null)
						continue;// skip this one, full instance objects?
					for(Object o : scc)
					{
						toretHashMap.put(o, rep);						
					}
					
				}
				
				
				return toretHashMap;
			}




			private Object getASootField(Set scc) {
			    for(Object o : scc)
			    {
			    	if(o instanceof SootField)
			    	{
			    		return o;
			    	}
			    }
			    return null;
				
			}




			public  Stack queueingStack = new Stack();
		    public  Set visited = new HashSet();   
		//    public List<Set> locksetStack = new ArrayList<Set>();// to detlete soon
		    
		    public Stack monitoringStack  = new Stack();
		    public Set grey = new HashSet();
		    public Set black = new HashSet();
		    
			private  void deadlockAvoidance0(ContextGraph csGraph, EntryStatement entry, DirectedPseudograph ddg, boolean instLock) {				
			//	locksetStack.clear();// It works only for dynamic analysis, for static analysis, sometimes, the exit may be executed before a branch
		        queueingStack.clear();
		        visited.clear();
		    	if(!visited.contains(entry))
		    	{
		    	    visited.add(entry);
		    		queueingStack.push(entry);// note that the systemstack is for simulating the recurisve call, different from the monitoring stack, which stores the ancestor info of a path
				}
		    	
				monitoringStack.clear();
				grey.clear();
				black.clear();

			
				while(!queueingStack.isEmpty())
				{
				    Object pop =queueingStack.pop();	// maintain the histroy inforamtion
				    if(!grey.contains(pop) && !black.contains(pop))// first popping, first entering the subgraph
				    {
				    	grey.add(pop);
				    	monitoringStack.push(pop);
				    	
				    	// keep the traversal going
					    List children =csGraph.getAllSuccs(pop);// ug.getSuccsOf(pop);
					    queueingStack.push(pop);	// double poping mechanism
					    for(int i = children.size()-1; i>=0; i--)
					    {
					    	Object child = children.get(i);	
					    	// here, visist the edge, do not visit inside the following branch, it would miss some unvisited edges with the target nodes  visited.
					    	
					    	if(!visited.contains(child))
					    	{
					    	    visited.add(child);
					    		queueingStack.push(child);				    		
					    	}
					    }
					    
					    if(pop instanceof EntryStatement)
					    {
					    	//System.out.println("enter" + ((EntryStatement)pop).getMsig());

					    	entry_update_stack_orderGraph(((EntryStatement) pop).getMsig(), monitoringStack, ddg, instLock);

							    
					    }
					    else if (pop instanceof ExitStatement) {
					    //	System.out.println("exit" + ((ExitStatement)pop).getMsig());
						   // exit_update_stack(((ExitStatement) pop).getMsig(), locksetStack,instLock);	
						}
					    
					    if(pop instanceof InvokeBeginStatement)
					    {
					    	//System.out.println("invokebegin" + ((InvokeBeginStatement)pop).getJimpleStmt());
					    }
					    if(pop instanceof InvokeEndStatement)
					    {
					    	//System.out.println("invokeend" + ((InvokeEndStatement)pop).getJimpleStmt());
					    }
				    }
				    else if(grey.contains(pop)){// second popping, leave the subgraph completely.
				    	// no need to put your children and you into the queue any more
				    	grey.remove(pop);
				    	Object object = monitoringStack.pop();
				    	if(object !=pop)
				    		throw new RuntimeException("what is wrong");
				    	black.add(pop);				    	
					}
				    // the above monitoring stakc is properly maintained!
				    
				    
				    
				    
				}	
			}

//			private void exit_update_stack(String msig, List<Set> locksetStack2, boolean instLock) {
//				locksetStack2.remove(locksetStack2.size()-1);		
//				System.out.println("exit" + msig);
//			}
// may be 
			private void entry_update_stack_orderGraph(String msig,
					List<Set> monitorStack, DirectedPseudograph ddg, boolean instLock) {
				// there may be multiple paths to this one considering the branch, however, it is ok from the method level view.
				// no matter how many barnaches inside a method, a exit can clear every thing. 
				SootMethod method = Scene.v().getMethod(msig);

				    
				List<CriticalSection> csL = getCriticalSections(method);
				
				
				
				if(monitorStack.size()<1) throw new RuntimeException("at least contain the entry statement!");
				
				

				    

				    
				Set interBeforeLocks = getInterBeforeLocks_monitorstack(monitorStack.subList(0, monitorStack.size()-1), instLock);// the before method! do not include the final one, the current method!
				
				
				
				Set intraLocks = getMethodCSlocks(method, instLock);	
				Set intraNoReentrant = noReentrant(intraLocks, interBeforeLocks);
				formOrderOnGraph(interBeforeLocks, intraNoReentrant, ddg);			
				

				    
				HashSet<CriticalSection> roots = new HashSet<CriticalSection>();
				for(CriticalSection cs:csL)
				{
					if(cs.nestLevel==1)
					{
						roots.add(cs);
					}
				}				
				formOrderOnGraph_intra(roots, interBeforeLocks, ddg,instLock);			
			}

			private Set noReentrant(Set intraLocks, Set interBeforeLocks) {
				intraLocks.removeAll(interBeforeLocks);				
				return intraLocks;
			}




			private Set getPoint2S(Local l) {
			   PointsToAnalysis p2 = Scene.v().getPointsToAnalysis();
				PointsToSetInternal p2s =(PointsToSetInternal)p2.reachingObjects(l);
				final HashSet set = new HashSet();
				p2s.forall(new P2SetVisitor() {
					
					@Override
					public void visit(Node n) {
						if(n.getType() instanceof AnySubType)
							return;
						if(n.getType() instanceof RefType)
						{
							RefType ref = (RefType)n.getType();
							String classname =ref.getSootClass().getName();
							if(Domain.shouldInstruThis_ClassFilter(classname)|| classname.startsWith("java."))// java.lang.Object can be a monitro too
							{
								set.add(n);
							}
						}
						
					}
				});
				
				return set;
			}

			private void formOrderOnGraph_intra(HashSet<CriticalSection> roots,
					Set outers, DirectedPseudograph ddg, boolean instLock) {
				// origs is for non-reentrant local filtering
               for(CriticalSection cs : roots)
               {
            	   Stack tmpStack = new Stack();
            	   visit(cs, outers, ddg, tmpStack, instLock);
               }			
			}

			private void visit(CriticalSection cs, Set interbeforeLocks,
					DirectedPseudograph ddg, Stack tmpStack, boolean instLock) {				
				Local curLocal = (Local)(cs.origLock);
				SootField curField = AfixInfo.getGlobalwithLocal(curLocal);
				if(curField==null) return;
				
				Set intraBeforeLocks = formASet(tmpStack);				
				Set beforeLocks = new HashSet();
				beforeLocks.addAll(interbeforeLocks);
				beforeLocks.addAll(intraBeforeLocks);
				
				Set intraCSLocks = getCSlocks(cs, instLock);
				Set intraCSNonReentrants = noReentrant(intraCSLocks, beforeLocks);
				formOrderOnGraph(intraBeforeLocks, intraCSNonReentrants, ddg);// it is not important whether the before contains reentrant locks, it just contains the lock
				// we do not need to consider the outer-intraCS relation as we have considered in the inter- mode
	
				tmpStack.push(intraCSNonReentrants);// always matching the exit
			   Set<CriticalSection> children =cs.childSections;
				for(CriticalSection child : children)
				{
					visit(child, interbeforeLocks, ddg, tmpStack,instLock);
				}	
				tmpStack.pop();
			}

			private Set formASet(Stack tmpStack) {
				Set toret= new HashSet();
				for(Object o : tmpStack)
				{
					Set tmp = (Set)o;
					toret.addAll(tmp);
				}
				return toret;
			}




			private void formOrderOnGraph(Set formedSet, Set origs,
					DirectedPseudograph ddg) {
				for(Object o: formedSet)
				{
					for(Object local:origs)
					{
						if(!ddg.containsVertex(o)) ddg.addVertex(o);
						if(!ddg.containsVertex(local)) ddg.addVertex(local);
						ddg.addEdge(o, local);
					}
				}			
			}

			private Set getInterBeforeLocks_monitorstack(List monitorStack, boolean instLock) {
				Set<SootMethod> methods =getNestingMethods(monitorStack);
				Set set = new HashSet();
				for(SootMethod nested:methods)
				{
					set.addAll(getMethodCSlocks(nested, instLock));
				}			
				return set;
			}

			private Set getMethodCSlocks(SootMethod method, boolean instLock) {				
				List<CriticalSection> csL = getCriticalSections(method);
		
				Set allIntraLocks = new HashSet();				
				for(CriticalSection cs :csL)
				{
					Local l =(Local)cs.origLock;
					try {
						String ls = l.getName();
					} catch (Exception e) {
						System.err.println(method.getName() + " " + method.getDeclaringClass().getName());
						
						List<CriticalSection> csL2 = getCriticalSections(method);
					}
					
					if(l.getName().startsWith("localFromGlobal"))
					{
						SootField sf = AfixInfo.getGlobalwithLocal(l);
						allIntraLocks.add(sf);							
					}
					else {				
						if(instLock)
						{
							allIntraLocks.addAll(getPoint2S(l));
						}					
					}
				}
				return allIntraLocks;
			}
			
			private Set getCSlocks(CriticalSection cs, boolean instLock) {				
			
		
				Set allIntraLocks = new HashSet();				
				
				{
					Local l =(Local)cs.origLock;
					if(l.getName().startsWith("localFromGlobal"))
					{
						SootField sf = AfixInfo.getGlobalwithLocal(l);
						allIntraLocks.add(sf);							
					}
					else {				
						if(instLock)
						{
							allIntraLocks.addAll(getPoint2S(l));
						}					
					}
				}
				return allIntraLocks;
			}




			private Set<SootMethod> getNestingMethods(List monitorStack) {
				Set<SootMethod> ret = new HashSet<SootMethod>();
				Stack calling = new Stack();
				for(int i=0; i< monitorStack.size(); i++)
				{
					Statement stmt =(Statement) monitorStack.get(i);
					if(stmt instanceof EntryStatement)
					{
						calling.push(stmt);
					}
					else if(stmt instanceof ExitStatement)
					{
						Object o =calling.peek();
						if(o instanceof EntryStatement)
						{
							EntryStatement entry = (EntryStatement)o;
							if(entry.getMsig().equals(stmt.getMsig()))
							{
								calling.pop();
							}
							else {
								throw new RuntimeException("what is up");
							}
						}
					}
				}
				for(Object o : calling)
				{					
					 String enterwhat = ((EntryStatement)o).getMsig();
					ret.add(Scene.v().getMethod(enterwhat));
				}
				
				return ret;
				
				
			  //  for(int i =0;i<monitorStack.size(); i++)
//			    {
//			    	Statement stmt =(Statement) monitorStack.get(i);
//			    	if(stmt instanceof EntryStatement)
//			    	{
//			    		String enterwhat = ((EntryStatement)stmt).getMsig();
//			    		boolean foundMatch = false;
//			    		for(int j=i; j<monitorStack.size(); j++)// yes, from i is ok
//			    		{
//			    			Statement tmp =  (Statement)monitorStack.get(j);
//			    		    if(tmp instanceof ExitStatement)
//			    		    {
//			    		    	ExitStatement exit = (ExitStatement)tmp;
//			    		    	if(exit.getMsig().equals(enterwhat))
//			    		    	{
//			    		    		foundMatch = true;
//			    		    	}
//			    		    }
//			    		}
//			    		if(!foundMatch)
//			    		{
//			    			ret.add(Scene.v().getMethod(enterwhat));
//			    			
//			    		}
//			    	}
//			    	
//			    }
				
				
			}




			private List<CriticalSection> getCriticalSections(SootMethod method) {
				List list = new ArrayList();
				if (method.isConcrete()) {
					
					Body b = method.retrieveActiveBody();	
					
				//	Body clone = (Body)b.clone();// for recovering
					UnitGraph eug = new ExceptionalUnitGraph( // this oen would add nop to the body, sign!!
							b);
					SynchronizedRegionFinder ta = new SynchronizedRegionFinder(
							eug, b, true);
					Chain units = b.getUnits();
					Unit lastUnit = (Unit) units.getLast();
					FlowSet fs = (FlowSet) ta.getFlowBefore(lastUnit);
					// all tns are here
    				if(fs!=null)
    				{
    					
    				    for (Iterator iterator = fs.iterator(); iterator
								.hasNext();) {
    				    	SynchronizedRegionFlowPair srfp = (SynchronizedRegionFlowPair) iterator.next();
    				    	CriticalSection cSection = (srfp).tn;
    				    	if(cSection.origLock==null && cSection.entermonitor==null)
    				    	{
    				    		continue;// this is the buggy output CS due to the nop generated in the EnhancedUnitGraph!, avoid it temporarily.
    				    	}
    				    	
    				    	list.add(cSection);
    				    	//Value orig =cSection.origLock;
    				    }
    				}
    				
    				
    			//	method.setActiveBody(clone);// 
					// add the results to the list of results
					
				}
				return list;
			}
		}));
		
		PackManager.v().runPacks();//1
		PackManager.v().writeOutput();// DUMP!
	    
		SootAgent4Fixing.sootDestroyNecessary();
	}

	



	public static void setUnitRef_Xedges_Phase(List list) {
		for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			CSMethod rCS = pair.getO2();
			if(pcCS.getMethod_type().equals(CSMethod.PCMethod) && rCS.getMethod_type().equals(CSMethod.RMethod))
			{
				String m1sig =pcCS.getMsig();
				String m2sig = rCS.getMsig();
				SootMethod pcm= Scene.v().getMethod(m1sig);
				SootMethod rm = Scene.v().getMethod(m2sig);				
				
				String pString =pcCS.getpAnc();// the format is jcode+ " " + line, line is for help identification!
				String cString = pcCS.getcAnc();
				String rString = rCS.getrAnc();
				
				Unit punit = identifyUnit(pcm, pString);
				Unit cunit = identifyUnit(pcm, cString);
				Unit runit = identifyUnit(rm, rString);
				
				pcCS.setPunit(punit);
				pcCS.setCunit(cunit);				
				Body pcbb =pcm.getActiveBody();
				UnitGraph pcug = new BriefUnitGraph(pcbb);// give u one chance
		    	Set xedges = LocalUnitGraphReachable.getXedgesOfProtected(pcug, punit, cunit);
		    	pcCS.setXedges(xedges);	
		    	pcCS.setBb(pcbb);
		    	pcCS.setUg(pcug);// only set the unitref is useless, the motherborad should be maintained too
		    	
				rCS.setRunit(runit);
				Body rbb = rm.getActiveBody();
				UnitGraph rug  = new BriefUnitGraph(rbb);
				rCS.setBb(rbb);
				rCS.setUg(rug);			    	
			}
			else {
				throw new RuntimeException("checking the type!");
			}	
		}
		
	}

	
    public static void genUniquePoints4PCM_phase(List list) {
    	for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			
			
			UnitGraph ugg =pcCS.getUg();
			Set xedges = pcCS.getXedges();
			if(xedges==null) throw new RuntimeException();
			
	    	for(Object x : xedges)
	    	{
	    		Xedge xedge =(Xedge)x;
	    		if(xedge.getUniquePoint()==null)
	    		{
	    			XedgesLocker.fixUniquePoint(ugg, xedge);
	    		}
	    		// now every xedge has a non-null uniquePoint
	    		if(xedge.getUniquePoint()==null)  throw new RuntimeException();	    		
	    	}	
		}		
	}

    
	public static void applyLocking_phase(List list) {
		int bugId =-1;
	//	Parameters.singleLock =true;
		for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			CSMethod rCS = pair.getO2();
			bugId ++;
			
			
			XedgesLocker.initializeGlock(bugId, pcCS, rCS);		
			XedgesLocker.lockWholeMethod(bugId, pcCS);
			XedgesLocker.lockSingleNode(bugId, rCS);
//			XedgesLocker.lockXedgesOfPCM(bugId, pcCS);
//			XedgesLocker.lockSingleNode(bugId, rCS);			
		}
		
	}

	static HashMap<String, String> orig2wildcard = new HashMap<String, String>();
    static HashMap<String, String> new2old_s = new HashMap<String, String>();
	public static Unit identifyUnit(SootMethod sm1, String pString) {
		if(!sm1.hasActiveBody()) sm1.retrieveActiveBody();
		Body b = sm1.getActiveBody();

		int lastBlank = pString.lastIndexOf(' ');
		
		String realPstring = pString.substring(0, lastBlank);
		int line  = Integer.parseInt(pString.substring(lastBlank+1));
		
		orig2wildcard.clear();
		Body bb=wildcard_shadow(b);
		Iterator it =b.getUnits().iterator();
		Iterator it2 = bb.getUnits().iterator();
		//
		

		while (it.hasNext() &&it2.hasNext()) {
			Unit object = (Unit) it.next();
			Unit shadow =(Unit)it2.next();
			 
			String patternString = shadow.toString().replace("$", "").replace("(", " ").replace(")", " ").replace("]", " ").replace("[", " ");
			String realString =realPstring.replace("$", "").replace("(", " ").replace(")", " ").replace("]", " ").replace("[", " ");
			 boolean match = false;
			 try {
				 match= Pattern.matches(patternString,realString);
			} catch (Exception e) {
				e.printStackTrace();
			}

			
			 
            // System.out.println(Pattern.matches("r..<example.URLParse: java.lang.String url> = #r.*","r0.<example.URLParse: java.lang.String url> = #r16"));//r..<example.URLParse: java.lang.String url> = #r.
			 
			 
			 if(match)
			 {
				 int tmpLine =SootAgent4Fixing.getLineNum(object);
					if(line ==tmpLine)// more coarse?, I attach the line NO got from the soot!, you should be consistent, SOOT!
					{						
					   return object;	
					}
					else {

						// any possible candidates or relax the constraints?
					}
			 }
			
			
		}
       // identifyUnit(sm1, pString);
		System.out.println(sm1.getName() + " " + sm1.getDeclaringClass().getName());
		
		if(true)
			throw new RuntimeException();
		return null;			
	
//		new2old_s.clear();
//		magicProcess(b, new2old_s);
//
//		Iterator it =b.getUnits().iterator();
//		Unit ret = null;
//		while (it.hasNext()) {
//			Unit object = (Unit) it.next();
//			if(object.toString().equals(pString))
//			{
//				ret = object;
//				break;
//			}
//			
//		}
//		magicProcessBack(b,new2old_s);
		
	}

	private static Body wildcard_shadow(Body bb) {
		// TODO Auto-generated method stub

		   Body b = (Body)bb.clone();
          Iterator<Local> lit =b.getLocals().iterator();
	      while (lit.hasNext()) {
			Local local = (Local) lit.next();
			String oldname = local.getName();
			char[] array = oldname.toCharArray();
			int indexOfNum = -1;
			for(int i=0;i<array.length;i++)
			{
				char ch = array[i];
				if(ch>='0' && ch<='9')
				{
					indexOfNum= i;
					break;
				}
			}
			String prefix = oldname.substring(0, indexOfNum);
			String number = oldname.substring(indexOfNum);
			
			String newName = prefix+ ".*";// . means any char, * means multiple .
			local.setName(newName);	
			
		}
	      return b;
	}
	
//	private static void magicProcessBack(Body b,
//			HashMap<String, String> new2old) {
//		 Iterator<Local> lit =b.getLocals().iterator();
//	      while (lit.hasNext()) {
//			Local local = (Local) lit.next();
//			String newname = local.getName();
//			String oldname =new2old.get(newname);
//			if(oldname!=null)
//			{
//				local.setName(oldname);				
//			}
//	      }
//			
//	}

//	private static void magicProcess(Body b, HashMap<String, String> new2old) {
//		// TODO Auto-generated method stub
//
//		// note that,jcode uses the name of delayed variable by $r1 and l0
////				$r1 = staticinvoke <java.lang.Thread: java.lang.Thread currentThread()>() :-1
////				l0 = virtualinvoke $r1.<java.lang.Thread: long getId()>() :-1
//				
////				  if(l.getType().equals(BooleanType.v()))
////		      l.setName(prefix + "z" + intCount++);
//		//  else if(l.getType().equals(ByteType.v()))
////		      l.setName(prefix + "b" + longCount++);
//		//  else if(l.getType().equals(ShortType.v()))
////		      l.setName(prefix + "s" + longCount++);
//		//  else if(l.getType().equals(CharType.v()))
////		      l.setName(prefix + "c" + longCount++);
//		//  else if(l.getType().equals(IntType.v()))
////		      l.setName(prefix + "i" + longCount++);
//		//  else if(l.getType().equals(LongType.v()))
////		      l.setName(prefix + "l" + longCount++);
//		//  else if(l.getType().equals(DoubleType.v()))
////		      l.setName(prefix + "d" + doubleCount++);
//				
//				// for consistent lookup, I need to increase the index for r variables and [b,s,ci,l] variables.
//          Iterator<Local> lit =b.getLocals().iterator();
//	      while (lit.hasNext()) {
//			Local local = (Local) lit.next();
//			String oldname = local.getName();
//			if(oldname.indexOf('b')!=-1)
//			{
//				int index = oldname.indexOf('b');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('s')!=-1) {
//				int index = oldname.indexOf('s');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('c')!=-1) {
//				int index = oldname.indexOf('c');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('i')!=-1) {
//				int index = oldname.indexOf('i');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('l')!=-1) {
//				int index = oldname.indexOf('l');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('r')!=-1) {
//				int index = oldname.indexOf('r');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=1) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			
//		
//			
//			
//			
//		}
//	}
	
	

	
	

}