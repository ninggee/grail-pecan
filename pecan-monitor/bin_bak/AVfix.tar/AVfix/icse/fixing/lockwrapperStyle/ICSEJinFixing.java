package AVfix.icse.fixing.lockwrapperStyle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pldi.locking.CriticalSection;
import pldi.locking.MethodLocker;
import pldi.locking.SynchronizedRegionFinder;
import pldi.locking.SynchronizedRegionFlowPair;

import soot.Body;
import soot.EntryPoints;
import soot.G;
import soot.Local;
import soot.Modifier;
import soot.PackManager;
import soot.PatchingChain;
import soot.RefType;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.EnterMonitorStmt;
import soot.jimple.ExitMonitorStmt;
import soot.jimple.Jimple;
import soot.jimple.JimpleBody;
import soot.jimple.Stmt;
import soot.jimple.internal.JReturnStmt;
import soot.jimple.internal.JReturnVoidStmt;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.pdg.EnhancedUnitGraph;
import soot.toolkits.scalar.FlowSet;
import soot.util.Chain;


import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;
import edu.hkust.clap.organize.SaveLoad;
import edu.hkust.clap.organize.SootAgent4Fixing;



import AVfix.debug.InjectChocalate;
import AVfix.edge.LocalEdge;
import AVfix.graph.ContextGraph;
import AVfix.icse.fixing.Domain;
import AVfix.icse.fixing.opt.Merge;
import AVfix.icse.fixing.opt.MergedBug;
import AVfix.icse.fixing.opt.MergedBugComponent;
import AVfix.icse.fixing.opt.Reduction;
import AVfix.locking.AfixInfo;

import AVfix.locking.Xedge;
import AVfix.locking.XedgesLocker;
import AVfix.unitgraph.LocalUnitGraphReachable;

public class ICSEJinFixing {

	public static void main(String[] args)
	{
		Object object = SaveLoad.load(SaveLoad.default_filename);
		 List list  =(List)object;// CSMethodPair List		
		 System.err.println("set the main class and the analyzedFolder in SootAgent4Fixing");
		 System.out.println("JIN's:");
			Properties.singleLock=false;
			//Properties.rInPC_reduct_opt =true;
			Properties.subsume_removal_opt = true;
			
		 ICSEJinFixing.fix(list, null);	
		 
//		//r.*.<org.exolab.jms.net.registry.Registry: org.exolab.jms.net.proxy.Proxy lookupjava.lang.String>()
//		//r13.<org.exolab.jms.net.registry.Registry: org.exolab.jms.net.proxy.Proxy lookupjava.lang.String>()
//		System.out.println(Pattern.matches("@",
//		"@"));
	}
	// batch style, do not fix one by one
	
	public static void fix(List list, ContextGraph csGraph) {

		
	//	final List newList =Reduction.reduce(list);// similar to JIn's removal
		
		//System.err.println(newList.size());	
		
		
		SootAgent4Fixing.sootLoadNecessary(list, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/jinSootOutput");
		setUnitRef_Xedges_Phase(list);
		Reduction.reduce(list);// similar to JIn's removal
		
		final List newlist = list;
	
		 PackManager.v().getPack("wjtp").add(new Transform("wjtp.transformer1", new SceneTransformer() {
			
			@Override
			protected void internalTransform(String phaseName, Map options) {	
				Set<CriticalSection> oldHealthyCSs =getCriticalSections();
				System.err.println("bad guys before applying locking:" + badguys);
				badguys =0;// reset
				
				long start1 = System.currentTimeMillis();
				//List lessList = new ArrayList();
				// jin's is too slow, help his to further optimization
				List<MergedBug> list =Merge.merge(newlist);
				int bugId =-1;
				//	Parameters.singleLock =true;
				for(Object elem : list)
				{
					bugId++;
					MergedBug mb = (MergedBug)elem;
					Iterator<MergedBugComponent> cit =mb.getContainers().iterator();
					HashSet<SootMethod> methods = new HashSet<SootMethod>();
 					while (cit.hasNext()) {
						MergedBugComponent mergedBugComponent = (MergedBugComponent) cit
								.next();
						SootMethod sm =mergedBugComponent.getMethod();
						methods.add(sm);
					}
					
			//		XedgesLocker.initializeGlock(bugId, methods);
					
					Iterator<MergedBugComponent> cit2 =mb.getContainers().iterator();					
 					while (cit2.hasNext()) {
						MergedBugComponent mergedBugComponent = (MergedBugComponent) cit2
								.next();
						SootMethod sm =mergedBugComponent.getMethod();
//						if(mergedBugComponent.getProUnits().size()==1)
//						{
//							Unit runit = (Unit)mergedBugComponent.getProUnits().toArray()[0];
//							XedgesLocker.lockSingleUnit(bugId, sm,runit);
//						}
//						else {
//							XedgesLocker.lockWholeMethod(bugId, sm);
//						}
					//	XedgesLocker.lockWholeMethod(bugId, sm);

						AddLockCallLibNoCtxt.addLockCalls(sm, bugId);
					}					
				}				
				long end1 = System.currentTimeMillis();
				System.err.println("time of fixing AV:" + (end1-start1));
				   SootMethod SM = Scene.v().getMainMethod();
				   InjectChocalate.addTimeReport(SM);
				   
				   if(Properties.removeSynch)
				   {
					   for(CriticalSection cs : oldHealthyCSs)
					   {
						   change2locallock(cs, Properties.removeWait);// if exceptionalend is null now, throw exception!
					   }
					   removalSynchronziedWord(Properties.removeWait);
				   }
				   if(Properties.report)
				   {
					   addReport2AllHealthyCSs_nonLocalized();// include the newly created
				   }
				
			}

			private void addReport2AllHealthyCSs_nonLocalized() {
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {			
						
						SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {
							if(sootMethod.isSynchronized())// avoid the deadlocks, later on, fix the syncFinder bug and do more solid!
							{
								//if(!containsWaitNotify(sootMethod))
								{
									 sootMethod.setModifiers(sootMethod.getModifiers() & ~Modifier.SYNCHRONIZED);
									 MethodLocker.addlock(sootMethod);
								}
								
							}
							
							InjectChocalate.addLockReport4HealthyCS_ignoreNullExcEnd(sootMethod);	
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
				
			}




			private void removalSynchronziedWord(boolean removeWait) {
				
				Set<CriticalSection> ret = new HashSet<CriticalSection>();
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {
							if(sootMethod.isSynchronized())// avoid the deadlocks, later on, fix the syncFinder bug and do more solid!
							{
								if(!removeWait)
									continue;
								if(!containsWaitNotify(sootMethod))
								{
									 sootMethod.setModifiers(sootMethod.getModifiers() & ~Modifier.SYNCHRONIZED);
										
								}
								if(removeWait)
								{
									removeWaits(sootMethod.getActiveBody());
								}
								 //MethodLocker.addlock(sootMethod);
							}
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
			   
			
			}




			public  int serialNo = 0;
			private void change2locallock(CriticalSection cSection, boolean removeWait)
			{
				SootMethod method = cSection.method;
				Body b = method.retrieveActiveBody();
				UnitGraph  eug = new EnhancedUnitGraph(
						b);

				if(!removeWait)
				{
					if(cSection.waits!=null && cSection.waits.size()!=0)
					{
						return;// complex, do not touch it
					}
					if(cSection.notifys!=null && cSection.notifys.size()!=0)
					{
						return;
					}
				}
				
				
				Chain units = b.getUnits();
				Unit lastUnit = (Unit) units.getLast();

			
		    	Stmt prep = cSection.prepStmt;
		    	
		    	
				Local lockObj = Jimple.v().newLocal(Properties.localizedPrefix + (serialNo++),
						RefType.v("java.lang.Object"));
				;
	
				// add local lock obj
				// addedLocalLockObj[i] = true;
				b.getLocals().add(lockObj);
	
				// assign new object to lock obj
				Stmt newStmt = Jimple.v().newAssignStmt(lockObj,
						Jimple.v().newNewExpr(RefType.v("java.lang.Object")));
				

						// initialize new object
						
				SootClass objectClass = Scene.v().loadClassAndSupport(
						"java.lang.Object");
				RefType type = RefType.v(objectClass);
				SootMethod initMethod = objectClass.getMethod("void <init>()");
				Stmt initStmt = Jimple.v().newInvokeStmt(
						Jimple.v().newSpecialInvokeExpr(lockObj, initMethod.makeRef(),
								Collections.EMPTY_LIST));
				
				units.insertAfter(newStmt, prep);
				units.insertAfter(initStmt,newStmt);
				
				EnterMonitorStmt enter = (EnterMonitorStmt)cSection.entermonitor;
				enter.setOp(lockObj);
				Set<ExitMonitorStmt> exits =cSection.getExitMonitors();
				for(ExitMonitorStmt exit : exits)
				{
					exit.setOp(lockObj);
				}  	//System.out.println("lock:" + cSection.origLock + " "+cSection.prepStmt);
				    	
				
				if(removeWait)
				{
					removeWaits(b);
				}
				   
				
				b.validateLP_nouse();
		
				
				
				
			
				
			}




			private void removeWaits(Body b) {
				PatchingChain<Unit> units =b.getUnits();
				HashSet<Unit > toremove = new HashSet<Unit>();
				for(Unit unit : units)
				{
					Stmt stmt = (Stmt) unit;
					if(stmt.containsInvokeExpr())
					{
						if(stmt.getInvokeExpr().getMethod().equals("wait")
					  || stmt.getInvokeExpr().getMethod().equals("notify")
					  || stmt.getInvokeExpr().getMethod().equals("notifyAll"))
						{
							toremove.add(stmt);
						}
					}
				}
				units.removeAll(toremove);
				
			}

			private List<CriticalSection> getCriticalSections(SootMethod method) {
				List list = new ArrayList();
				if (method.isConcrete()) {
					
					Body b = method.retrieveActiveBody();	
					
				//	Body clone = (Body)b.clone();// for recovering
					UnitGraph eug = new ExceptionalUnitGraph( // this oen would add nop to the body, sign!!
							b);
					SynchronizedRegionFinder ta = new SynchronizedRegionFinder(
							eug, b, true);
					Chain units = b.getUnits();
					Unit lastUnit = (Unit) units.getLast();
					FlowSet fs = (FlowSet) ta.getFlowBefore(lastUnit);
					// all tns are here
    				if(fs!=null)
    				{
    					
    				    for (Iterator iterator = fs.iterator(); iterator
								.hasNext();) {
    				    	SynchronizedRegionFlowPair srfp = (SynchronizedRegionFlowPair) iterator.next();
    				    	CriticalSection cSection = (srfp).tn;
    				    	if(cSection.origLock==null && cSection.entermonitor==null)
    				    	{
    				    		continue;// this is the buggy output CS due to the nop generated in the EnhancedUnitGraph!, avoid it temporarily.
    				    	}
    				    	
    				    	list.add(cSection);
    				    	//Value orig =cSection.origLock;
    				    }
    				}
    				
    				
    			//	method.setActiveBody(clone);// 
					// add the results to the list of results
					
				}
				return list;
			}


			private Set<CriticalSection> getCriticalSections() {	
				Set<CriticalSection> ret = new HashSet<CriticalSection>();
			    Iterator< SootClass> it2 =Scene.v().getApplicationClasses().iterator();
			    while (it2.hasNext()) {
					SootClass sootClass = (SootClass) it2.next();
					Iterator<SootMethod> mit =sootClass.getMethods().iterator();
					while (mit.hasNext()) {SootMethod sootMethod = (SootMethod) mit.next();

						boolean should =Domain.shouldInstrumentMethod(sootMethod);
						if(!should)
							continue;
							
						try {							
							List<CriticalSection> css =getCriticalSections(sootMethod);
							for(CriticalSection cs : css)
							{
								if(isHealthy(cs))
								{
									ret.add(cs);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
							//System.err.println(sootMethod.toString());
							
						}	
						
					}
				}
			    return ret;
			}



            int badguys =0;
			private boolean isHealthy(CriticalSection cs) {
				if(cs.entermonitor!=null && cs.origLock !=null && cs.prepStmt!=null
						&& cs.exceptionalEnd!=null)
					return true; 
				badguys ++;
				return false;
			}




			private boolean containsWaitNotify(SootMethod sootMethod) {
			   if(sootMethod.hasActiveBody())
			   {
				   Iterator<Unit> it =sootMethod.getActiveBody().getUnits().iterator();
			       while (it.hasNext()) {
					Stmt unit = (Stmt) it.next();
					if(unit.containsInvokeExpr())
					{
						String mName =unit.getInvokeExpr().getMethod().getName();
					    if(mName.equals("wait") || mName.equals("notify")
					    		||mName.equals("notifyAll")
					    		||mName.equals("join")
					    		||mName.equals("start"))
					    	return true;
					}
					
				}
			   }
			   return false;
			}



		}));
		
		PackManager.v().runPacks();//1
		PackManager.v().writeOutput();// DUMP!
	    
		SootAgent4Fixing.sootDestroyNecessary();
	}

	



	public static void setUnitRef_Xedges_Phase(List list) {
		for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			CSMethod rCS = pair.getO2();
			if(pcCS.getMethod_type().equals(CSMethod.PCMethod) && rCS.getMethod_type().equals(CSMethod.RMethod))
			{
				String m1sig =pcCS.getMsig();
				String m2sig = rCS.getMsig();
				SootMethod pcm= Scene.v().getMethod(m1sig);
				SootMethod rm = Scene.v().getMethod(m2sig);				
				
				String pString =pcCS.getpAnc();// the format is jcode+ " " + line, line is for help identification!
				String cString = pcCS.getcAnc();
				String rString = rCS.getrAnc();
				
				Unit punit = identifyUnit(pcm, pString);
				Unit cunit = identifyUnit(pcm, cString);
				Unit runit = identifyUnit(rm, rString);
				
				pcCS.setPunit(punit);
				pcCS.setCunit(cunit);				
				Body pcbb =pcm.getActiveBody();
				UnitGraph pcug = new BriefUnitGraph(pcbb);// give u one chance
		    	Set xedges = LocalUnitGraphReachable.getXedgesOfProtected(pcug, punit, cunit);
		    	pcCS.setXedges(xedges);	
		    	pcCS.setBb(pcbb);
		    	pcCS.setUg(pcug);// only set the unitref is useless, the motherborad should be maintained too
		    	
				rCS.setRunit(runit);
				Body rbb = rm.getActiveBody();
				UnitGraph rug  = new BriefUnitGraph(rbb);
				rCS.setBb(rbb);
				rCS.setUg(rug);			    	
			}
			else {
				throw new RuntimeException("checking the type!");
			}	
		}
		
	}

	
    public static void genUniquePoints4PCM_phase(List list) {
    	for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			
			
			UnitGraph ugg =pcCS.getUg();
			Set xedges = pcCS.getXedges();
			if(xedges==null) throw new RuntimeException();
			
	    	for(Object x : xedges)
	    	{
	    		Xedge xedge =(Xedge)x;
	    		if(xedge.getUniquePoint()==null)
	    		{
	    			XedgesLocker.fixUniquePoint(ugg, xedge);
	    		}
	    		// now every xedge has a non-null uniquePoint
	    		if(xedge.getUniquePoint()==null)  throw new RuntimeException();	    		
	    	}	
		}		
	}

    
//	public static void applyLocking_phase(List list) {
//		int bugId =-1;
//	//	Parameters.singleLock =true;
//		for(Object elem : list)
//		{
//			CSMethodPair pair = (CSMethodPair)elem;
//			CSMethod pcCS = pair.getO1();// must be pc!
//			CSMethod rCS = pair.getO2();
//			bugId ++;
//			
//			XedgesLocker.initializeGlock(bugId, pcCS, rCS);		
//			XedgesLocker.lockWholeMethod(bugId, pcCS);
//			XedgesLocker.lockWholeMethod(bugId, rCS);
////			XedgesLocker.lockXedgesOfPCM(bugId, pcCS);
////			XedgesLocker.lockSingleNode(bugId, rCS);			
//		}
//		
//	}

	static HashMap<String, String> orig2wildcard = new HashMap<String, String>();
    static HashMap<String, String> new2old_s = new HashMap<String, String>();
	public static Unit identifyUnit(SootMethod sm1, String pString) {

		try {
			if(!sm1.hasActiveBody()) sm1.retrieveActiveBody();
		} catch (Exception e) {
		   System.out.println(sm1.getDeclaringClass().getName() + sm1.getName());
		   
		}
		
			Body b = sm1.getActiveBody();
			Body bclone = (Body) b.clone();


			int lastBlank = pString.lastIndexOf(' ');
			
			String realPstring = pString.substring(0, lastBlank);
			int line  = Integer.parseInt(pString.substring(lastBlank+1));
			realPstring = realPstring.replace("*", "");// remove the original * , if makes the matching difficult, I also remove the * embraced by "" in the pattern,
			
			orig2wildcard.clear();
			Body bb=wildcard_shadow(b);
			Iterator it =b.getUnits().iterator();
			Iterator it2 = bb.getUnits().iterator();
			//
			

			while (it.hasNext() &&it2.hasNext()) {
				Unit object = (Unit) it.next();
				Unit shadow =(Unit)it2.next();
				
				// remove the * in ""
				
				char[] arrayOfChar = shadow.toString().toCharArray();
				int numOfMaoHao= 0;
				String newOne  = "";

				for(int i=0; i< arrayOfChar.length; i++)
				{
					char charAtI =arrayOfChar[i];
					if(charAtI=='"')
					{
						numOfMaoHao++;
					}
					if(charAtI == '*' && numOfMaoHao%2==1)// ji shu
					{
						
					}
					else {

						newOne = newOne + "" + charAtI;

					}
				}
				String patternString = newOne.toString().replace("$", "").replace("(", "").replace(")", "").replace("]", "").replace("[", "").replace("{", "").replace("}", "");
				String realString =realPstring.replace("$", "").replace("(", "").replace(")", "").replace("]", "").replace("[", "").replace("{", "").replace("}", "");
//				System.out.println(realPstring);
//				System.out.println(newOne);
//				System.out.println(realString);
				
				
				boolean match = false;
				 try {
					 match= Pattern.matches(patternString,realString);
				} catch (Exception e) {
					System.err.println(b.toString());
					System.out.println(patternString);
					System.out.println(realString);
					e.printStackTrace();
				}

				
				 
	            // System.out.println(Pattern.matches("r..<example.URLParse: java.lang.String url> = #r.*","r0.<example.URLParse: java.lang.String url> = #r16"));//r..<example.URLParse: java.lang.String url> = #r.
				 
				 
				 if(match)
				 {
					 int tmpLine =SootAgent4Fixing.getLineNum(object);
						if(line ==tmpLine)// more coarse?, I attach the line NO got from the soot!, you should be consistent, SOOT!
						{						
						   return object;	
						}
						else {

							// any possible candidates or relax the constraints?
						}
				 }		
			}
	       // identifyUnit(sm1, pString);
		//	System.out.println(sm1.getName() + " " + sm1.getDeclaringClass().getName());
			
			sm1.setActiveBody(bclone);
			if(true)
			{

				throw new RuntimeException();
			}
				
			return null;			
		
//			new2old_s.clear();
//			magicProcess(b, new2old_s);
	//
//			Iterator it =b.getUnits().iterator();
//			Unit ret = null;
//			while (it.hasNext()) {
//				Unit object = (Unit) it.next();
//				if(object.toString().equals(pString))
//				{
//					ret = object;
//					break;
//				}
//				
//			}
//			magicProcessBack(b,new2old_s);
			
		
		
	}

	private static Body wildcard_shadow(Body bb) {
		// TODO Auto-generated method stub

		   Body b = (Body)bb.clone();
          Iterator<Local> lit =b.getLocals().iterator();
	      while (lit.hasNext()) {
			Local local = (Local) lit.next();
			String oldname = local.getName();
			char[] array = oldname.toCharArray();
			int indexOfNum = -1;
			for(int i=0;i<array.length;i++)
			{
				char ch = array[i];
				if(ch>='0' && ch<='9')
				{
					indexOfNum= i;
					break;
				}
			}
			String prefix = oldname.substring(0, indexOfNum);
			String number = oldname.substring(indexOfNum);
			
			String newName = prefix+ ".*";// . means any char, * means multiple .
			local.setName(newName);	
			
		}
	      return b;
	}
	
//	private static void magicProcessBack(Body b,
//			HashMap<String, String> new2old) {
//		 Iterator<Local> lit =b.getLocals().iterator();
//	      while (lit.hasNext()) {
//			Local local = (Local) lit.next();
//			String newname = local.getName();
//			String oldname =new2old.get(newname);
//			if(oldname!=null)
//			{
//				local.setName(oldname);				
//			}
//	      }
//			
//	}

//	private static void magicProcess(Body b, HashMap<String, String> new2old) {
//		// TODO Auto-generated method stub
//
//		// note that,jcode uses the name of delayed variable by $r1 and l0
////				$r1 = staticinvoke <java.lang.Thread: java.lang.Thread currentThread()>() :-1
////				l0 = virtualinvoke $r1.<java.lang.Thread: long getId()>() :-1
//				
////				  if(l.getType().equals(BooleanType.v()))
////		      l.setName(prefix + "z" + intCount++);
//		//  else if(l.getType().equals(ByteType.v()))
////		      l.setName(prefix + "b" + longCount++);
//		//  else if(l.getType().equals(ShortType.v()))
////		      l.setName(prefix + "s" + longCount++);
//		//  else if(l.getType().equals(CharType.v()))
////		      l.setName(prefix + "c" + longCount++);
//		//  else if(l.getType().equals(IntType.v()))
////		      l.setName(prefix + "i" + longCount++);
//		//  else if(l.getType().equals(LongType.v()))
////		      l.setName(prefix + "l" + longCount++);
//		//  else if(l.getType().equals(DoubleType.v()))
////		      l.setName(prefix + "d" + doubleCount++);
//				
//				// for consistent lookup, I need to increase the index for r variables and [b,s,ci,l] variables.
//          Iterator<Local> lit =b.getLocals().iterator();
//	      while (lit.hasNext()) {
//			Local local = (Local) lit.next();
//			String oldname = local.getName();
//			if(oldname.indexOf('b')!=-1)
//			{
//				int index = oldname.indexOf('b');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('s')!=-1) {
//				int index = oldname.indexOf('s');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('c')!=-1) {
//				int index = oldname.indexOf('c');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('i')!=-1) {
//				int index = oldname.indexOf('i');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('l')!=-1) {
//				int index = oldname.indexOf('l');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=0) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			else if (oldname.indexOf('r')!=-1) {
//				int index = oldname.indexOf('r');
//				String prefix = oldname.substring(0, index+1);
//				String number = oldname.substring(index+1);
//				int varIndex = Integer.parseInt(number);
//				if(varIndex>=1) varIndex++;
//				String newName = prefix+ varIndex;
//				local.setName(newName);
//				new2old.put(newName, oldname);
//			}
//			
//		
//			
//			
//			
//		}
//	}
	
	

	
	

}
