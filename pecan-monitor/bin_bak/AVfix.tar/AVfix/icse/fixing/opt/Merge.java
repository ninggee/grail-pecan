package AVfix.icse.fixing.opt;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;

import AVfix.icse.fixing.Properties;
import AVfix.unitgraph.LocalUnitGraphReachable;

public class Merge {

	static HashSet toremove = new HashSet();
	public static List merge(List list) {
		pariwiseChecking(list);// for evaluation
		List<MergedBug> toret = new ArrayList<MergedBug>();
		System.out.println("before merging:" + list.size() );
		while(list.size()!=0)
		{
			Object elem = list.remove(0);
			CSMethodPair pair = (CSMethodPair)elem;
			MergedBug mb =MergedBug.formMergedBug(pair);
			merge0(mb, list, toret);// recursive call, merge until saturation! the reason is that, newly added one may introduce some new friend
		// the list removes elements iteratively in merge0
			// toret contains the mbs.
		}
		System.err.println("after merging, I have " + toret.size() + " super bugs to fix after merging");
		
		for(MergedBug mb : toret)
		{
			intraMerge(mb);	
			System.err.println("mergedbug " + mb.hashCode()+ " contains N components: " + mb.getContainers().size());
		}
		return toret;
	}

	private static void pariwiseChecking(List list) {
		for(int i= 0; i< list.size(); i++)
		{
			for(int j= i; j< list.size(); j++ )
			{
				if(j!=i)
				{
					Object elemI = list.get(i);
					CSMethodPair pairI = (CSMethodPair)elemI;
					 CSMethod pcI  =pairI.getO1();
				     CSMethod rI = pairI.getO2();
				     Set protectedSetI = LocalUnitGraphReachable.protectedUnitsSet(pcI);
				     
						Object elemJ = list.get(j);
						CSMethodPair pairJ = (CSMethodPair)elemJ;
						 CSMethod pcJ  =pairJ.getO1();
					     CSMethod rJ = pairJ.getO2();
					     Set protectedSetJ = LocalUnitGraphReachable.protectedUnitsSet(pcJ);
					     
					    
					     
					     if(protectedSetI.contains(rJ.getRunit()))
					     {
					    	 if(protectedSetJ.contains(rI.getRunit()))
					    	 {
					    		 //if(!pcI.getMsig().contains("<init>"))
					    		 {
					    			// if(!rJ.getMsig().contains("<init>"))
					    			 {
					    				 System.out.println();
							    		 System.out.println("==============");
							    		 System.out.println(pcI.getMsig());
							    		 System.out.println(pcI.getpAnc() + pcI.getcAnc() + rI.getrAnc());
							    		 System.out.println("include: the j of ==> ");
							    		 System.out.println(rJ.getMsig());
							    		 System.out.println(pcJ.getpAnc() + pcJ.getcAnc() + rJ.getrAnc());
					    			 }
					    		 }
					    		 
					    	 }
					     }
//					     <org.w3c.tools.resources.FramedResource: void postAttributeChangeEvent(int,java.lang.Object)>
//					     $r3 = r0.<org.w3c.tools.resources.FramedResource: org.w3c.tools.resources.event.AttributeChangedListener attrListener> 462virtualinvoke r0.<org.w3c.tools.resources.FramedResource: void fireAttributeChangeEvent(org.w3c.tools.resources.event.AttributeChangedEvent)>(r2) 467r0.<org.w3c.tools.resources.FramedResource: org.w3c.tools.resources.event.AttributeChangedListener attrListener> = null 119
//					     include: the j of ==> 
//					     <org.w3c.tools.resources.FramedResource: void postAttributeChangeEvent(int,java.lang.Object)>
//					     r0.<org.w3c.tools.resources.AttributeHolder: org.w3c.tools.resources.Attribute[] attributes> = null 28r0.<org.w3c.tools.resources.AttributeHolder: org.w3c.tools.resources.Attribute[] attributes> = $r3 499$r7 = r0.<org.w3c.tools.resources.FramedResource: org.w3c.tools.resources.Attribute[] attributes> 465
//
//					     [java] <org.w3c.tools.resources.Resource: void setValue(int,java.lang.Object)>
//					     [java] specialinvoke r0.<org.w3c.tools.resources.AttributeHolder: void setValue(int,java.lang.Object)>(i0, r1) 627$r20 = r0.<org.w3c.tools.resources.Resource: org.w3c.tools.resources.Attribute[] attributes> 628r0.<org.w3c.tools.resources.AttributeHolder: org.w3c.tools.resources.Attribute[] attributes> = null 28
//					     [java] ==> 
//					     [java] <org.w3c.tools.resources.Resource: void setValue(int,java.lang.Object)>
//					     [java] $r20 = r0.<org.w3c.tools.resources.Resource: org.w3c.tools.resources.Attribute[] attributes> 628virtualinvoke r0.<org.w3c.tools.resources.Resource: void markModified()>() 630r0.<org.w3c.tools.resources.AttributeHolder: org.w3c.tools.resources.Attribute[] attributes> = null 28
//					     [java]     
					    
					     
//					     [java] <org.w3c.tools.resources.DirectoryResource: org.w3c.tools.resources.ResourceReference createDefaultResource(java.lang.String,org.w3c.tools.resources.RequestInterface)>
//					     [java] r7 = virtualinvoke r0.<org.w3c.tools.resources.DirectoryResource: org.w3c.tools.resources.ResourceReference addResource(org.w3c.tools.resources.Resource,java.util.Hashtable)>(r6, r4) 425virtualinvoke r0.<org.w3c.tools.resources.DirectoryResource: void markModified()>() 426$r13 = r0.<org.w3c.tools.resources.event.ResourceEventQueue: org.w3c.tools.resources.event.ResourceEventQueue$QueueCell last> 69
//					     [java] ==> 
//					     [java] <org.w3c.tools.resources.DirectoryResource: org.w3c.tools.resources.ResourceReference createDefaultResource(java.lang.String,org.w3c.tools.resources.RequestInterface)>
//					     [java] r6 = virtualinvoke r0.<org.w3c.tools.resources.DirectoryResource: org.w3c.tools.resources.Resource index(java.lang.String,java.util.Hashtable,org.w3c.tools.resources.RequestInterface)>(r1, r4, r2) 420r7 = virtualinvoke r0.<org.w3c.tools.resources.DirectoryResource: org.w3c.tools.resources.ResourceReference addResource(org.w3c.tools.resources.Resource,java.util.Hashtable)>(r6, r4) 425r0.<org.w3c.tools.resources.event.ResourceEventQueue: org.w3c.tools.resources.event.ResourceEventQueue$QueueCell last> = r5 70
//					     [java] ==============
//					     if(protectedSetJ.contains(rI.getRunit()))
//					     {
//					    	 if(!protectedSetI.contains(rJ.getRunit()))
//					    	 {
//					    		 if(!pcJ.getMsig().contains("<init>"))
//					    		 {
//					    			 if(!rI.getMsig().contains("<init>"))
//					    			 {
//					    				 System.out.println();
//							    		 System.out.println("==============");
//							    		 System.out.println(pcJ.getMsig());
//							    		 System.out.println(pcJ.getpAnc() + pcJ.getcAnc() + rJ.getrAnc());
//							    		
//							    		 System.out.println("include: the j of ==> ");
//							    		 System.out.println(rI.getMsig());
//							    		 System.out.println(pcI.getpAnc() + pcI.getcAnc() + rI.getrAnc());
//							    		
//					    			 }
//					    		 }
//					    		
//					    		
//					    		 
//					    	 }
//					     }
//					     if(MergedBugComponent.hasNonEmptyIntersect(protectedSetI, protectedSetJ))
//					     {
//					    	
//					    	 {
//					    		 if(pcI.getpAnc()!=pcJ.getpAnc() && pcI.getcAnc()!=pcJ.getcAnc())
//					    		 {
//					    			 System.out.println();
//						    		 System.out.println("==============");
//						    		 System.out.println(pcI.getMsig());
//						    		 System.out.println(pcI.getpAnc() + pcI.getcAnc() + rI.getrAnc());
//						    		 System.out.println("==> ");
//						    		 System.out.println(pcJ.getMsig());
//						    		 System.out.println(pcJ.getpAnc() + pcJ.getcAnc() + rJ.getrAnc());
//					    		 }
//					    		 
//					    	 }
//					     }
					     
					     
				}

			     
			     
			}
		}
		
	}

	private static void merge0(MergedBug mb, List list, List<MergedBug> toret) {
		if(list.size()==0)// the last one scenario
		{
			toret.add(mb);
			return;
		}
		boolean successever = false;
		toremove.clear();
		
		for(int i=0;i<list.size();i++)
		{
			CSMethodPair tmp = (CSMethodPair)list.get(i);
			successever = mb.mergeWith(tmp);
			if(successever)
			{
				toremove.add(tmp);
			}
		}
		if(toremove.size()!=0)
		{
			for(Object o : toremove)
			{
				list.remove(o);
			}	
			merge0(mb, list, toret);
			return;
		}
		else {// saturation
			toret.add(mb);// over
			return;
		}
		
		
		
		
	}
	
	private static void intraMerge(MergedBug mb) {
		Set<MergedBugComponent> components=mb.getContainers();
		List<MergedBugComponent> comList = new ArrayList<MergedBugComponent>();
		comList.addAll(components);
		Set<MergedBugComponent> newComps = new HashSet<MergedBugComponent>();
		while(comList.size()!=0)
		{
			Object elem = comList.remove(0);
			MergedBugComponent pair = (MergedBugComponent)elem;
			
			intraMerge0(pair, comList, newComps);// recursive call, merge until saturation! the reason is that, newly added one may introduce some new friend
		// the list removes elements iteratively in merge0
			// toret contains the mbs.
		}
		mb.setContainers(newComps);
		
	}
	
	private static void intraMerge0(MergedBugComponent mb, List list, Set<MergedBugComponent> toret) {
		if(list.size()==0)// the last one scenario
		{
			toret.add(mb);
			return;
		}
		boolean successever = false;
		toremove.clear();
		
		for(int i=0;i<list.size();i++)
		{
			MergedBugComponent tmp = (MergedBugComponent)list.get(i);
			successever = mb.intraEat(tmp);
			if(successever)
			{
				toremove.add(tmp);
			}
		}
		if(toremove.size()!=0)
		{
			for(Object o : toremove)
			{
				list.remove(o);
			}	
			intraMerge0(mb, list, toret);
			return;
		}
		else {// saturation
			toret.add(mb);// over
			return;
		}		
	}
	
}
