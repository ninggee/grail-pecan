package AVfix.icse.fixing.opt;

import java.util.HashSet;
import java.util.Set;

import soot.Unit;

import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;

public class MergedBug {

	public Set<CSMethodPair> buggyPairs = new HashSet<CSMethodPair>();
	
	public Set<MergedBugComponent> containers = new HashSet<MergedBugComponent>();
	
	public static MergedBug formMergedBug(CSMethodPair pair)
	{
		MergedBug mergedBug = new MergedBug();
		mergedBug.buggyPairs.add(pair);
		
		CSMethod pcCS = pair.getO1();// must be pc!
		CSMethod rCS = pair.getO2();
		
		MergedBugComponent  c1 = MergedBugComponent.formContainer(pcCS);
		MergedBugComponent c2 = MergedBugComponent.formContainer(rCS);
		
		mergedBug.containers.add(c1);
		mergedBug.containers.add(c2);
		
		return mergedBug;		
	}

	public boolean  mergeWith(CSMethodPair pair)
	{
		
		// In pair, r ! in PC, for those r in PC, remove them!
		CSMethod pcCS = pair.getO1();// must be pc!
		CSMethod rCS = pair.getO2();
		
//		Set pcXedges =pcCS.getXedges();
//		Unit runit =rCS.getRunit();
		
		Set<MergedBugComponent> containers =this.getContainers();
		boolean success = false;// 
		boolean success2 = false;
		for(MergedBugComponent container : containers)
		{ // the semantic is that, some nodes in one container may form AV with some node in another container!
			success = success || container.eat(pcCS);
			success2 = success2 ||container.eat(rCS);
			if(success )
			{
				Set<Unit> set =container.getProUnits();
//				System.out.println("container:");
//				for(Object o: set)
//				{
//					System.out.println(o);
//				}
//				
//				System.out.println("pcCS:");
//				System.out.println(pcCS.getMsig());
//				System.out.println(pcCS.getpAnc());
//				System.out.println(pcCS.getcAnc());
//				
//				System.out.println();
			}
			if(success2)
			{
				Set<Unit> set =container.getProUnits();
//				System.out.println("container:");
//				for(Object o: set)
//				{
//					System.out.println(o);
//				}
//				
//				System.out.println("rCS:");
//				System.out.println(rCS.getMsig());
//				System.out.println(rCS.getpAnc());
//				System.out.println(rCS.getcAnc());
//				
//				System.out.println();
			}
		}
		
		
		if(!success && !success2)// one success is enough!
		{
			// can never be included
			return false;// note that the pair is not added
		}
		else {
			if(!success)// succes2 =true
			{
				MergedBugComponent buildContainer = MergedBugComponent.formContainer(pcCS);
				containers.add(buildContainer);
			}
			if(!success2)
			{
				if(!success2)
				{
					MergedBugComponent buildContainer = MergedBugComponent.formContainer(rCS);
					containers.add(buildContainer);
				}
			}
		}
		this.buggyPairs.add(pair);
		return true;

		//==> for rCS, should not be done at the same time as pcCS, as the containers may be udpated
		

		
	}
	
	
	public Set<CSMethodPair> getBuggyPairs() {
		return buggyPairs;
	}

	public void setBuggyPairs(Set<CSMethodPair> buggyPairs) {
		this.buggyPairs = buggyPairs;
	}

	public Set<MergedBugComponent> getContainers() {
		return containers;
	}

	public void setContainers(Set<MergedBugComponent> containers) {
		this.containers = containers;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
