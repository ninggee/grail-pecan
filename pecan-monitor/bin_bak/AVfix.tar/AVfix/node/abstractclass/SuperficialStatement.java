package AVfix.node.abstractclass;

import soot.jimple.Stmt;

public abstract class SuperficialStatement extends Statement{
    
    
}
