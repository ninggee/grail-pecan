package AVfix.graph;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.HashMap;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.ext.DOTExporter;
import org.jgrapht.graph.DirectedPseudograph;

import com.sun.org.apache.bcel.internal.generic.NEW;

import AVfix.edge.CallEdge;
import AVfix.edge.ReturnEdge;
import AVfix.edge.abstractclass.ControlEdge;
import AVfix.node.CommonLocalStatement;
import AVfix.node.EntryStatement;
import AVfix.node.ExitStatement;
import AVfix.node.InvokeBeginStatement;
import AVfix.node.InvokeEndStatement;
import AVfix.node.TStatement;
import AVfix.node.abstractclass.ConcreteStatement;
import AVfix.node.abstractclass.Statement;

import popl.petrinet.element.Transition;
import popl.petrinet.ops.PetriNet;
import soot.jimple.Stmt;

public class ContextGraphVisualizer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	

	}

	
	public static void visualize(ContextGraph csGraph, String fileName) { 

		File file = new File(fileName);
		FileWriter fw;
		try {
			fw = new FileWriter(file);			
			export4PetriNet(fw, csGraph);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	
	public static void export4PetriNet(Writer writer, ContextGraph g)
    {
        PrintWriter out = new PrintWriter(writer);
        String indent = "  ";
        String connector;

       // if (g instanceof DirectedGraph) {
            out.println("digraph G {");
            connector = " -> ";
//        } else {
//            out.println("graph G {");
//            connector = " -- ";
//        }

        for (Object v : g.coreG.vertexSet()) {
            out.print(indent + getPetriNetName((Statement)v));            
            if(v instanceof Transition)// two special cases for the node shape or color
            {
            	 out.print(
                         " [shape = box]");
            }
            if(g.getThreadRoots().contains(v))
            {
            	 out.print(
                 " [color=red]");
            }
           
            
            out.println(";");
        }

        for (Object e : g.coreG.edgeSet()) {
            String source = getPetriNetName(g.coreG.getEdgeSource((ControlEdge)e));
            String target = getPetriNetName(g.coreG.getEdgeTarget((ControlEdge)e));


            out.print(indent + source + connector + target);     
            if(e instanceof CallEdge || e instanceof ReturnEdge)// special case for the edge
            {
            	out.print(
                " [style = bold]");
            }
            
            out.println(";");
        }

        out.println("}");
        out.flush();
    }

	public static int curCounter = 0;
	public static HashMap<Integer, Integer> hashcode2counter =new HashMap<Integer, Integer>();
	public static  int fakeHashCode(int hashcode)
	{
		if(hashcode2counter.get(hashcode)==null)
		{
			hashcode2counter.put(hashcode, curCounter++);
		}
		return hashcode2counter.get(hashcode).intValue();
	}

	private static String getPetriNetName(Statement v) {
		String core = "";
	if(v instanceof EntryStatement)
	{
		String msig =((EntryStatement)v).getMsig();
		String mname =getmName(msig);
		//System.out.println(mname);
		core= "Entry_" + mname + fakeHashCode(v.hashCode());//v.hashCode();
	}
	else if(v instanceof ExitStatement)
	{
		String msig =(v).getMsig();
		String mname =getmName(msig);
		core = "Exit_" + mname+fakeHashCode(v.hashCode());
	}
	else if( v instanceof InvokeBeginStatement)
	{
		int x = ((ConcreteStatement)v).getJimpleStmt().hashCode();
		core = "InvokeBegin" + fakeHashCode(x);//((ConcreteStatement)v).getJimpleStmt().hashCode();
	}
	else if (v instanceof InvokeEndStatement) {
		int x =((ConcreteStatement)v).getJimpleStmt().hashCode();
		core = "InvokeEnd" + fakeHashCode(x);
	}
	else if(v instanceof CommonLocalStatement){		
		Stmt st = ((ConcreteStatement)v).getJimpleStmt();
		core = "S" +  fakeHashCode(st.hashCode());;// I am not interested of the type
	}
	else if (v instanceof TStatement) {
		core = "T" +  fakeHashCode(v.hashCode());;
	}
	else {
		throw new RuntimeException("double checking the type:" + v.getClass());
	}		
		return "\"" + core + "\"";
	}


	private static String getmName(String msig) {
		//<example.ExampleThread: void run()>
		int maohao =msig.indexOf(':');
		int lbrace = msig.indexOf('(');
		msig = msig.substring(maohao+1, lbrace);
		int lastBlank = msig.lastIndexOf(' ');		
		
		return msig.substring(lastBlank+1);
	}
		
	

}
