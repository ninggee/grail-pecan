package AVfix.icse.fixing.lockwrapperStyle;

import java.util.List;

import soot.SootMethod;

public class Triple {
	public SootMethod method = null;
	public  int  bugId = -1;
	public List<String> ctxtList = null;
	public SootMethod getMethod() {
		return method;
	}
	public void setMethod(SootMethod method) {
		this.method = method;
	}
	public int getBugId() {
		return bugId;
	}
	public void setBugId(int bugId) {
		this.bugId = bugId;
	}
	public List<String> getCtxtList() {
		return ctxtList;
	}
	public void setCtxtList(List<String> ctxtList) {
		this.ctxtList = ctxtList;
	}

}
