package AVfix.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import edu.hkust.clap.datastructure.StackTraceElement_lpxz;
import edu.hkust.clap.organize.CSMethod;

import soot.SootMethod;
import soot.Unit;
import soot.jimple.Stmt;
import soot.toolkits.graph.DirectedGraph;
import AVfix.manager.MethodManager;
import AVfix.node.EntryStatement;
import AVfix.node.abstractclass.Statement;

public class ContextGraphTraversal {


	public static List emptyList = new ArrayList();
	public static Stack systemStack = new Stack();
    public static Set visited = new HashSet();   

  
	//==============================================================
	
	// now comes the CSGraph
	// better change the name ! unit is for unit, here, it is the node,,
	
	public static Set allInBetween(ContextGraph csG, Statement pnode , Statement cnode)
    {  // check carefully for the exceptional branches
        Set reachable =all_reachable_no_cross(csG, pnode, cnode);
        Set backreachable = all_backreachable_no_cross(csG, cnode, pnode);
        Set intersectSet = intersect(reachable, backreachable);
        intersectSet.add(pnode);
        intersectSet.add(cnode);
        return intersectSet;    	
    }
	
	// now comes the CSGraph
	// better change the name ! unit is for unit, here, it is the node,,
	private static Set local_reachable(ContextGraph csG, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =csG.getLocalSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
	
	private static Set local_backreachable(ContextGraph csG, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =csG.getLocalPrecs(pop);//simplify it
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}

	
	private static Set local_reachable_no_cross(ContextGraph csG, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =getLocalSuccs_awareof_bound(csG, pop, bound);//csG.getLocalSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
	private static List getLocalSuccs_awareof_bound(ContextGraph csG, Object pop,
			Object bound) {
		if(pop!=bound)
		{
			return csG.getLocalSuccs(pop);
		}
		else {
			return emptyList;
		}	
	}
	
	private static Set local_backreachable_no_cross(ContextGraph csG, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =getLocalPrecs_awareof_bound(csG, pop, bound);//csG.getLocalSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}

	private static List getLocalPrecs_awareof_bound(ContextGraph csG, Object pop,
			Object bound) {
		if(pop !=bound)
		{
			return csG.getLocalPrecs(pop);
		}
		else {
			return emptyList;
		}
	}
	
	//================================================global 
	private static Set all_reachable(ContextGraph csG, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =csG.getAllSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    		
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}

	
	private static Set all_backreachable(ContextGraph csG, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =csG.getAllPrecs(pop);//simplify it
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}

	
	private static Set all_reachable_no_cross(ContextGraph csG, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =getAllSuccs_awareof_bound(csG, pop, bound);//csG.getLocalSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
	private static List getAllSuccs_awareof_bound(ContextGraph csG, Object pop,
			Object bound) {
		if(pop!=bound)
		{
			return csG.getAllSuccs(pop);
		}
		else {
			return emptyList;
		}	
	}
	
	private static Set all_backreachable_no_cross(ContextGraph csG, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children =getAllPrecs_awareof_bound(csG, pop, bound);//csG.getLocalSuccs(pop);// ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}

	private static List getAllPrecs_awareof_bound(ContextGraph csG, Object pop,
			Object bound) {
		if(pop !=bound)
		{
			return csG.getAllPrecs(pop);
		}
		else {
			return emptyList;
		}
	}
	
	//=======================================================================

	
	public static Set  intersect(List list1, List list2)
	{
		Set ret= new HashSet();
		for(Object o  : list1)
		{
			if (list2.contains(o))
			{
				ret.add(o);
			}
		}
		
		return ret;
	}
	
	public static Set  intersect(Set list1, Set list2)
	{
		Set ret= new HashSet();
		for(Object o  : list1)
		{
			if (list2.contains(o))
			{
				ret.add(o);
			}
		}
		
		return ret;
	}
	public static void main(String[] args) {
		

	}

	public static Set<Statement> interProtectedStatements(ContextGraph csGraph,CSMethod pcCS) {
		if(pcCS.isPC())
		{
			List<StackTraceElement_lpxz> tmpList = pcCS.getStes();		
			ContextGraphMethod graphPCM = MethodManager.search4GCSmethod_withFullName(pcCS.getMsig(), tmpList.subList(0, tmpList.size() -1));// the secondmethod's ctxt : 0-> (size-2)
			SootMethod pcm =graphPCM.getBb().getMethod();// it must be processed, just now or earlier
			
			Statement pnode =graphPCM.getU2S().get(pcCS.getPunit());
			Statement cnode =graphPCM.getU2S().get(pcCS.getCunit());
			
			// pnode and cnode may be invokeStatement
			if(!csGraph.coreG.containsVertex(pnode))
			{
				// 
				pnode =ContextGraphGen.invoke2begin.get(pnode);
				
			}
			if(!csGraph.coreG.containsVertex(cnode))
			{
				cnode = ContextGraphGen.invoke2end.get(cnode);
			}
			
			Set<Statement> inPC =ContextGraphTraversal.allInBetween(csGraph, pnode, cnode);
			return inPC;
		}
		else if(pcCS.isR()){
			Set<Statement> toret = new HashSet<Statement>();
			List<StackTraceElement_lpxz> tmpList2 = pcCS.getStes();	
			ContextGraphMethod graphRM = MethodManager.search4GCSmethod_withFullName(pcCS.getMsig(), tmpList2.subList(0, tmpList2.size() -1));// the secondmethod's ctxt : 0-> (size-2)
			SootMethod rm =graphRM.getBb().getMethod();// it must be processed, just now or earlier
		   
			Stmt runit = (Stmt)pcCS.getRunit();
			Statement rnode =graphRM.getU2S().get(runit);
			if(runit.containsInvokeExpr()) throw new RuntimeException("it should be field access" + runit);
			toret.add(rnode);			

			if(!csGraph.coreG.containsVertex(rnode))
			{
				throw new RuntimeException("it is not invoking statement");
			}
			return toret;
		}
		else {
			throw new RuntimeException();
		}
		
		
	}

}
