package AVfix.icse.fixing.opt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import soot.SootMethod;
import soot.Unit;
import soot.jimple.Stmt;
import AVfix.graph.ContextGraph;
import AVfix.graph.ContextGraphGen;
import AVfix.graph.ContextGraphPetrify;
import AVfix.graph.ContextGraphTraversal;
import AVfix.graph.ContextGraphMethod;
import AVfix.graph.ContextGraphVisualizer;
import AVfix.icse.fixing.ICSEJinFixing;
import AVfix.icse.fixing.Properties;
import AVfix.manager.MethodManager;
import AVfix.node.abstractclass.Statement;
import edu.hkust.clap.datastructure.StackTraceElement_lpxz;
import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;

public class Reduction {
// all optimzations are based on the contextgraph, interprocedurally
	
	public static List reduce(List list) {
		if(Properties.rInPC_reduct_opt)
		{
			list =rInPcReduction(list);
		}
		if(Properties.subsume_removal_opt)
		{
			list =subsumeReduction( list);
		}
//		if(Parameters.merge_of_jin_opt)// not proper here!, apply_locking phase
//		{
//			
//		}
		 ContextGraph csGraph=	ContextGraph.create_get_SingletonCSGraph(list);// in case that the csGraph is not created!, .e
        // e.g., the above two branches are not executed		
		 System.err.println("petri net size:"+ (csGraph.coreG.vertexSet().size() *2));
	//	 ContextGraphPetrify.petrify(csGraph);
	//	 ContextGraphVisualizer.visualize(csGraph, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/tmp/specjbb_dotfile");
		return list;
	}
	
	private static List rInPcReduction(List list) {
 System.err.println("before rInPC reduction:" + list.size());
		 ContextGraph csGraph=	ContextGraph.create_get_SingletonCSGraph(list);
		
		 
//		 CSGraphPetrify.petrify(csGraph);
//		 CSGraphVisualizer.visualize(csGraph, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/tmp/dotfile");
		 List ret= new ArrayList();
		
		for(Object elem : list)
		{
			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod pcCS = pair.getO1();// must be pc!
			CSMethod rCS = pair.getO2();
			

			Set<Statement> inPC =ContextGraphTraversal.interProtectedStatements(csGraph,pcCS);
			Set<Statement> inR =ContextGraphTraversal.interProtectedStatements(csGraph,rCS);
			if(inPC.containsAll(inR))// Inter-procedural optimization based on the context graph
			{
				
			}
			else {
				ret.add(pair);
			}
		}
		 System.err.println("after rInPC reduction:" + ret.size());
			

			
		return ret;
	}

	public static List subsumeReduction(List list) {
			 ContextGraph csGraph=	ContextGraph.create_get_SingletonCSGraph(list);
	//		 CSGraphPetrify.petrify(csGraph);
	//		 CSGraphVisualizer.visualize(csGraph, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/tmp/dotfile");
			 List ret= new ArrayList();
			 HashMap<Set, CSMethodPair> involved2Pair = new HashMap<Set, CSMethodPair>();
			 System.err.println("before subsume reduction:" + list.size());
			 
			for(Object elem : list)
			{
				CSMethodPair pair = (CSMethodPair)elem;
				CSMethod pcCS = pair.getO1();// must be pc!
				CSMethod rCS = pair.getO2();
				

				Set<Statement> inPC =ContextGraphTraversal.interProtectedStatements(csGraph,pcCS);
				Set<Statement> inR =ContextGraphTraversal.interProtectedStatements(csGraph,rCS);
				inPC.addAll(inR);
				
				
				
				// update the involved2Pair, the keys should be un-subsumed by others
				Iterator<Set> it =involved2Pair.keySet().iterator();
				boolean shouldAdd = true;
				Set shouldRemoved = new HashSet();
				while (it.hasNext()) {
					Set involved = (Set) it.next();
					if(Reduction.subsumedBy(inPC, involved))
					{
						// no need to put it, 
						shouldAdd= false;
						break;
					}
					else if (Reduction.subsumedBy(involved,inPC)) {
						shouldRemoved.add(involved);
						// sunsumed and removed!
					}	
					else {
						// no one subsume each other
					}
				}	
				// execute the above orders:
				for(Object o: shouldRemoved)
				{
					involved2Pair.remove(o);
				}
				if(shouldAdd)
					involved2Pair.put(inPC, pair);
			}
			
			
			Collection unsubsumedPair =involved2Pair.values();
			for(Object o:list)
			{
				if(unsubsumedPair.contains(o))
					ret.add(o);
			}
			System.err.println("after subsume reduction:" + ret.size());
			
			return ret;
	
		}

	//subset OF
	public static boolean subsumedBy(Set<Statement> inPC, Set involved) {
		boolean ret = true;
		for(Statement tmp : inPC)
		{
			if(!involved.contains(tmp))
			{
				ret = false;
				return ret;
			}
		}	
		return ret;
	}



}
