package AVfix.node;

import AVfix.node.abstractclass.Statement;
import AVfix.node.abstractclass.SuperficialStatement;

public class EntryStatement extends SuperficialStatement{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
