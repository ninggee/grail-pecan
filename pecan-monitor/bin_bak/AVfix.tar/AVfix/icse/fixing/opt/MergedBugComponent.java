package AVfix.icse.fixing.opt;

import java.util.HashSet;
import java.util.Set;

import com.sun.org.apache.bcel.internal.generic.NEW;

import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;
import AVfix.graph.ContextGraph;
import AVfix.graph.ContextGraphMethod;
import AVfix.graph.ContextGraphTraversal;
import AVfix.node.abstractclass.Statement;
import AVfix.unitgraph.LocalUnitGraphReachable;
import soot.SootMethod;
import soot.Unit;
import soot.dava.internal.AST.ASTTryNode.container;
import soot.dava.toolkits.base.misc.ThrowNullConverter;

public class MergedBugComponent {
	// code container..
	public SootMethod sootMethod = null;// for method-level locking
	
	public Set<Unit> protectedUnits = new HashSet<Unit>();// if only one element, it is runit, otherwise, it must involve pc at least
	
	public Set<Statement> protectedStatements_inter = new HashSet<Statement>();
	public Set<Statement> getProtectedStatements_inter() {
		return protectedStatements_inter;
	}


	public SootMethod getMethod() {
		return sootMethod;
	}

	public void setMethod(SootMethod method) {
		this.sootMethod = method;
	}

	

	public Set<Unit> getProUnits() {
		return protectedUnits;
	}


	public static MergedBugComponent formContainer(CSMethod csMethod)
	{
		MergedBugComponent container = new MergedBugComponent();
		container.setMethod(csMethod.getBb().getMethod());
		container.getProUnits().addAll(LocalUnitGraphReachable.protectedUnitsSet(csMethod));	
		Set<Statement> interProtectedStatements = ContextGraphTraversal.interProtectedStatements(ContextGraph.getContextGraph(), csMethod);
		container.getProtectedStatements_inter().addAll(interProtectedStatements);
		return container;		
	}
	
	public static boolean hasNonEmptyIntersect(Set set1, Set set2)
	{
		for(Object o : set1)
		{
			if(set2.contains(o))
				return true;
		}
		return false;
	}

	public boolean eat(CSMethod pcCS) {
//		Set interProtectedStatements =  ContextGraphTraversal.interProtectedStatements(ContextGraph.getContextGraph(), pcCS);
//		Set thisProtectedStatements = this.getProtectedStatements_inter();
//		
		Set protectedSet = LocalUnitGraphReachable.protectedUnitsSet(pcCS);
		Set thisProtectedSet = this.getProUnits();
		// only locally!
		if(this.getMethod().getSignature().equals(pcCS.getBb().getMethod().getSignature()))
			{//this.setMethod(pcCS.getBb().getMethod()); // no need for this
				 if(hasNonEmptyIntersect(thisProtectedSet, protectedSet))
				{			// containAll is a special case!	
					this.getProUnits().addAll(protectedSet);
					return true;
				}			
			
		}
		return false;
		
	}


	public boolean intraEat(MergedBugComponent tmp) {
		Set protectedSet = tmp.getProUnits();
		Set thisProtectedSet = this.getProUnits();
		// only locally!
		if(this.getMethod().getSignature().equals(tmp.getMethod().getSignature()))
			{//this.setMethod(pcCS.getBb().getMethod()); // no need for this
				 if(hasNonEmptyIntersect(thisProtectedSet, protectedSet))
				{			// containAll is a special case!	
					this.getProUnits().addAll(protectedSet);
					return true;
				}			
			
		}
		return false;
	}


}
