package AVfix.debug;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.Lock;

import org.jgrapht.alg.CycleDetector;
import org.jgrapht.alg.StrongConnectivityInspector;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DirectedPseudograph;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class Chocalate {

	
	public static boolean enabled = true;
	public static DirectedPseudograph ddg = new DirectedPseudograph(DefaultEdge.class);
	public static HashMap l2t = new HashMap();
	public static HashMap l2localName = new HashMap();	
	
	public static long start = 0;
	
	public static void startClock()
	{
		start = System.currentTimeMillis();
	}
	
	public static void  endClock()
	{
		long end = System.currentTimeMillis();
		System.err.println("the process lasts for:" + (end-start));
		
	}
	public static void sayHello()
	{
		System.out.println("I am chocalate, hello.");
	}
	public static void printMyName(String classandmethod)
	{
		System.out.println(classandmethod);
	}
	
	public static void beforeLocking(long tid , Object monitor)
	{
		
		if(enabled)
		{		
			StackTraceElement[] array =Thread.currentThread().getStackTrace();
			StackTraceElement curStackEle = array[2];
			
			System.out.println( Thread.currentThread().getName()+ " tolock:" + monitor.hashCode()   );
			System.out.println(curStackEle.getClassName()+ "." + curStackEle.getMethodName());
			if(l2t.get(monitor)!=null)
			{
				
				Long longval =(Long)l2t.get(monitor);
				if(longval.longValue()!=tid)// aklready owned by other thread!
				{
					// tid-> longval. want to get
					if(!ddg.containsVertex(tid)) ddg.addVertex(tid);
					if(!ddg.containsVertex(longval)) ddg.addVertex(longval);
					if(!ddg.containsEdge(tid, longval))
					{
						
//						
					}
					// may form a new cycle!
					StrongConnectivityInspector sci = new StrongConnectivityInspector(ddg);
					List<Set> sccList= sci.stronglyConnectedSets();// ntoe there, we have the scc, not the cycle, scc is more strong than cycle
					for(Set scc : sccList)
					{
						if(scc.size()<2) continue; 
						System.err.println("cycle invovles" );
						for(Object object:  scc)
						{
						   System.err.print(l2localName.get(object)); ;	
						}
						System.err.println();
					}
				}
			}
		  	
		}
		
	}
	//! this one is not used:
	public static void afterLocking(long tid , Object monitor){
		if(enabled)
		{
			StackTraceElement[] array =Thread.currentThread().getStackTrace();
			StackTraceElement curStackEle = array[2];
			System.out.println( Thread.currentThread().getName()+ " locked:" + monitor.hashCode()   );
			System.out.println(curStackEle.getClassName()+ "." + curStackEle.getMethodName());
			//System.out.println( tid+ " locked " + local + " in method: " + curStackEle.getClassName()+ "." + curStackEle.getMethodName() );
			l2t.put(monitor, tid);
		}
		
		
	}
	public static void beforeUnlocking(long tid , Object monitor)
	{
		
		if(enabled)
		{
			//nothing to do
			try {
				StackTraceElement[] array =Thread.currentThread().getStackTrace();
				StackTraceElement curStackEle = array[2];
				
				System.out.println( Thread.currentThread().getName()+ " unlock:" + monitor.hashCode()   );
				System.out.println(curStackEle.getClassName()+ "." + curStackEle.getMethodName());
				
			//	System.out.println( tid+ " to unlock " + local + " in method: " + curStackEle.getClassName()+ "." + curStackEle.getMethodName() );
			} catch (Exception e) {
			// do not send me to the exceptional handler which keeps executing exitmonitor->throw->exitmonitor
			}
			
		//Thread.currentThread().dumpStack();
		}
		
	}
	public static void afterUnlocking(long tid , Object monitor)
	{
		if(enabled)
		{
			try {
				StackTraceElement[] array =Thread.currentThread().getStackTrace();
				StackTraceElement curStackEle = array[2];
				
			///	System.out.println( Thread.currentThread().getName()+ " unlocked:" + monitor.hashCode()   );
			//	System.out.println(curStackEle.getClassName()+ "." + curStackEle.getMethodName());
				if(l2t.get(monitor)!=null)
				{
					l2t.remove(monitor);
				}
				Set edges =ddg.incomingEdgesOf(tid);// cancel those edges.
				for(Object edge : edges)
				{
					ddg.removeEdge(edge);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		}
		
		// no need to remove the vertex, it may ask for others' locks, acting as the source of the arrow
	}
	


}
