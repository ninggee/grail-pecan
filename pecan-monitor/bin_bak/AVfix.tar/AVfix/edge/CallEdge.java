package AVfix.edge;

import AVfix.edge.abstractclass.ControlEdge;

public class CallEdge extends ControlEdge{

}
