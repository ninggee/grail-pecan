package AVfix.unitgraph;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Stack;

import edu.hkust.clap.organize.CSMethod;

import AVfix.locking.Xedge;



import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Pack;
import soot.PackManager;
import soot.PatchingChain;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.jimple.Jimple;
import soot.jimple.Stmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.toolkits.visitor.Visitor;
import soot.options.Options;
import soot.toolkits.graph.BlockGraph;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.ZonedBlockGraph;
import soot.toolkits.graph.pdg.RegionAnalysis;
import soot.toolkits.scalar.Pair;
import soot.util.Chain;


public class LocalUnitGraphReachable {

	public static Stack systemStack = new Stack();
    public static Set visited = new HashSet();   
    
    
   //public static HashMap<Pair, Set> pc2Protected= new HashMap<Pair, Set>();
   
   public static HashMap<Set, Set> protected2Xedges = new HashMap<Set, Set>();
     
   
   private static void fixUniquePoint(DirectedGraph ug, Xedge edge)
   {
	   UnitGraph unitGraph = (UnitGraph) ug;
	   Body bb = unitGraph.getBody();
	   PatchingChain<Unit> units = bb.getUnits();
	   if(edge.getUniquePoint()==null)
	   {
		// both the source and the target are not unique Points.
		  // given a goto b, a must be a goto statement
		   // for b, add x directly before b, do not redict the jumpings.
		   //for those indirect-source(b) except a are the same
		   //  a goto x
		   //  for direct-source(b) , adds goto to b, 

		  System.out.println(bb.toString()); 
		   Stmt a = (Stmt)edge.getO1();
		   Stmt b = (Stmt)edge.getO2();
		   if(!(a instanceof JIfStmt)) throw new RuntimeException("otherwise, a would have only 1 target");
		   List<Stmt> preds = ug.getPredsOf(b);
		   
		   Stmt x = Jimple.v().newNopStmt();// do nothing
		   units.insertBeforeNoRedirect(x, b);
		   
		   JIfStmt aif = (JIfStmt)a;
		   aif.setTarget(x);// no document, god...
		   
		   for(Stmt pred:preds)
		   {
			   if(pred.branches()!=true)// Jif or goto would return true
			   {
				  Stmt newGotoStmt = Jimple.v().newGotoStmt(b);
				  units.insertAfter(newGotoStmt, pred); 
			   }
		   }
		   edge.setUniquePoint(x);
		   System.err.println("*****************");
		   System.out.println(bb.toString()); 
	   }	
	   bb.validateLP();
   }
//    
    public static Set getXedgesOfProtected(DirectedGraph ug, Object pnode, Object cnode)
    {
        Pair tmp = new Pair(pnode, cnode);
        Set protectedSet = null;// pc2Protected.get(tmp);
        if(protectedSet ==null)
        {
        	 protectedSet =protectedSet(ug, pnode, cnode);
//        	 for(Object o : protectedSet)
//        	 {
//        		 System.out.println(o.toString());
//        	 }
        	// pc2Protected.put(tmp, protectedSet);
        }
        
        if(protected2Xedges.get(protectedSet)!=null)
        {
        	return protected2Xedges.get(protectedSet);
        }
        else {
        	Set headsOfProtected = new HashSet();
        	Iterator headIt =ug.getHeads().iterator();
        	while (headIt.hasNext()) {
    			Object head = (Object) headIt.next();
    			getXedgesOfProtected0(ug, head, protectedSet, headsOfProtected);
    			
    		}
        	protected2Xedges.put(protectedSet, headsOfProtected);
        	return headsOfProtected;
		}    	
    }
    public static Set slowGetXedgesOfProtected(DirectedGraph ug,Set protectedSet)
    {
    	Set headsOfProtected = new HashSet();
    	Iterator headIt =ug.getHeads().iterator();
    	while (headIt.hasNext()) {
			Object head = (Object) headIt.next();
			getXedgesOfProtected0(ug, head, protectedSet, headsOfProtected);			
		}    
    	return headsOfProtected;
    }
    
    
    
    private static void getXedgesOfProtected0(DirectedGraph ug, Object unit, 
			Set protectedSet, Set XedgesOfProtected) {    	
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children = ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	//check all the edges! an internal node with a VISITED external node as the /target may exist@!
		    	// simmilarly, the internal visited node (by an internal node) with an unvisited external node as the source may exist.
  	            
		    	Xedge edge=null;
		    	if(!protectedSet.contains(pop) && protectedSet.contains(child))
  	            {
		    		 edge = new Xedge((Unit)pop, (Unit)child);
		    		edge.setIncoming(true);
		    		
  	            	XedgesOfProtected.add(edge);// this is the head of the protectedSet
  	            //	edge.setUniquePoint(null);// in general null, later process in general
  	            	
  	            }
		    	if(protectedSet.contains(pop) && !protectedSet.contains(child))
		    	{
		    		 edge = new Xedge((Unit)pop, (Unit)child);
		    		edge.setIncoming(false);
		    		XedgesOfProtected.add(edge);// this is the head of the protectedSet
		    		//edge.setUniquePoint(null);// in general null, later process in general
		    	}
		    	
		    	
		    	
		    	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }		    
		}
	
	
    	
		
	}


	public static Set protectedSet(DirectedGraph ug, Object pnode , Object cnode)
    {  // check carefully for the exceptional branches
        Set reachable =reachable_no_cross(ug, pnode, cnode);
        Set backreachable = back_reachable_no_cross(ug, cnode, pnode);
        return intersect(reachable, backreachable);    	
    }
    

	private static Set reachable(DirectedGraph ug, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children = ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
  	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
    
    private static Set back_reachable(DirectedGraph ug, Object unit) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children = getSuccsOnReversedGraph(ug,pop);//ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
    
	private static List getSuccsOnReversedGraph(DirectedGraph ug, Object pop) {		
		return ug.getPredsOf(pop);
	}
	
	
	private static Set reachable_no_cross(DirectedGraph ug, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children = getSuccs_awareof_bound(ug, pop, bound);//ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
//		    	    if(child==null)
//		    	    {
//		    	    	System.out.println("what happened?");
//		    	    	
//		    	    }
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
	

	public static List emptyList = new ArrayList();
	private static List getSuccs_awareof_bound(DirectedGraph ug, Object pop,
			Object bound) {
		if(pop!=bound)
			return ug.getSuccsOf(pop);
		else
			return emptyList;
	}

	
	private static Set back_reachable_no_cross(DirectedGraph ug, Object unit, Object bound) {
    	Set toretSet = new HashSet();
        systemStack.clear();
        visited.clear();
		systemStack.push(unit);	
    	if(!visited.contains(unit))
    	{
    	    visited.add(unit);
    	}
	
		while(!systemStack.isEmpty())
		{
		    Object pop =systemStack.pop();			    
		    List children = getSuccs_onReversedGraph_awareof_bound(ug, pop, bound);//ug.getSuccsOf(pop);
		    for(int i = children.size()-1; i>=0; i--)
		    {
		    	Object child = children.get(i);	
		    	
		    	
		    	if(!visited.contains(child))
		    	{
		    	    visited.add(child);
		    		systemStack.push(child);				    		
		    	}
		    }
		    
		}
		toretSet.addAll(visited);
		return toretSet;
	}
	
	private static List getSuccs_onReversedGraph_awareof_bound(
			DirectedGraph ug, Object pop, Object bound) {
		if(pop!=bound)
			return ug.getPredsOf(pop);
		else
			return emptyList;
	}
	
	
	public static Set  intersect(List list1, List list2)
	{
		Set ret= new HashSet();
		for(Object o  : list1)
		{
			if (list2.contains(o))
			{
				ret.add(o);
			}
		}
		
		return ret;
	}
	
	public static Set  intersect(Set list1, Set list2)
	{
		Set ret= new HashSet();
		for(Object o  : list1)
		{
			if (list2.contains(o))
			{
				ret.add(o);
			}
		}
		
		return ret;
	}
	
	
	public static void main(String[] args) throws IOException { // wjtp.tn
		// @link LockProducer
        String argsOfToy2 = "-f J -pp -cp /home/lpxz/eclipse/workspace/Playground/bin:/home/lpxz/eclipse/workspace/soot24/bin Toy2";// soot.jimple.toolkits.thread.synchronizationLP.Jimples.HelloWorld"; // java.lang.Math
		String argsOfToyW = "-f J -pp -cp /home/lpxz/java_standard/jre/lib/jsse.jar:/home/lpxz/eclipse/workspace/openjms/bin -process-dir /home/lpxz/eclipse/workspace/openjms/bin"; // java.lang.Math
		//String argsOfToyW = "-f J -pp -cp /home/lpxz/java_standard/jre/lib/jsse.jar:/home/lpxz/eclipse/workspace/openjms/bin driver.OpenJMSDriver"; // java.lang.Math
		
		String argsOfJimpleHelloWorld = "-f J -pp -cp /home/lpxz/eclipse/workspace/Playground/bin:/home/lpxz/eclipse/workspace/soot24/bin soot.jimple.toolkits.thread.synchronizationLP.Jimples.HelloWorld"; // java.lang.Math
		String argsOfpaddleJar = "-f J -pp -cp /home/lpxz/eclipse/workspace/soot24/paddlePublic/ -process-dir /home/lpxz/eclipse/workspace/soot24/paddlePublic/"; // java.lang.Math
		// do not use the jar directly,
		// unzip it to a folder, and parse the folder like above.
		// /home/lpxz/javapool/jdk1.3.1_20/jre/lib/rt.jar

		String interString = argsOfToyW;
		String[] finalArgs = interString.split(" ");

		soot.Main.v().processCmdLine(finalArgs);
		
	
		
		List excludesList= new ArrayList();
		excludesList.add("jrockit.");
		excludesList.add("com.bea.jrockit");
		excludesList.add("sun.");
		Options.v().set_exclude(excludesList);
		
	///	Options.v().set_output_dir("paddle_public.jar");
	//	Options.v().set_output_jar(true);// same as the name as the outdir (actually substitue it), so must be set.
		
		
		Scene.v().loadNecessaryClasses();
		// Setup.setPhaseOptionsForPaddleWork();
//		Setup.setPhaseOptionsForSparkWork();



		
		 
		Pack jtp = PackManager.v().getPack("jtp");
		addgetRegionPackToJtp(jtp);
		// Pack wjtp = PackManager.v().getPack("wjtp");
		// addVisitorToWjtp(wjtp);

		PackManager.v().runPacks();// 1
		//PackManager.v().writeOutput();
		G.reset();
	}

	// List entryPoints=EntryPoints.v().methodsOfApplicationClasses();
	// List mainEntries = new ArrayList();
	// for(int i=0;i< entryPoints.size(); i++)
	// {
	// if(entryPoints.get(i).toString().contains("main"))
	// {
	// mainEntries.add(entryPoints.get(i));
	// }
	// }
	//
	// soot.Scene.v().setEntryPoints(mainEntries); // process : app and its
	// reachable methods.

	private static void addgetRegionPackToJtp(Pack jtp) {

		jtp.add(new Transform("jtp.getRegion", new BodyTransformer() {

			@Override
			protected void internalTransform(Body b, String phaseName,
					Map options) {
				SootMethod  sm =b.getMethod();
				if(!sm.getName().equals("main")) return;
				
				if(!sm.hasActiveBody())
				{
					return;
				}
				else {
					Body bb =sm.getActiveBody();
					UnitGraph ug = new BriefUnitGraph(bb);
					
					// for testing only
					Unit unit1 = randomUnit(bb);
					Unit unit2 = randomUnit(bb);
					while(unit1==null || unit2==null || unit2== unit1)
					{
						unit1 = randomUnit(bb);
						unit2= randomUnit(bb);
					}
					
					Set xedges= getXedgesOfProtected(ug, unit1, unit2);//maybe multiple incoming edges, prepare for it
					System.out.println("==================");
					for(Object o : xedges)
					{
						Xedge xedge = (Xedge)o;
//						if(xedge.isIncoming()) System.out.println("1");
							
//						if(xedge.getUniquePoint()==null)
//						{
//							System.err.println("=================");
//							System.err.println(xedge.getO1());
//							System.err.println(xedge.getO2());
//							
//							System.out.println(bb.getMethod().toString());
//							System.out.println(bb.getMethod().getDeclaringClass().getName());
//						    
//							fixUniquePoint(ug, xedge);
//							System.exit(1);
////							 Utils.drawDirectedGraphNBody(ug, bb,"random");
////							 System.exit(1);
//							 //if r1 == null goto exitmonitor r2
//							 //exitmonitor r2
//						}
//						else {
//						//	System.err.println("the unique point is:" + xedge.getUniquePoint());
//						}
						
					}
				}
			}

			 Random random  = new Random();
			private Unit randomUnit(Body bb) {
			   int size = bb.getUnits().size();
			   int randomvalue = random.nextInt(size);
			   
			   int i =0;
			  Iterator<Unit> it= bb.getUnits().iterator();
			  while (it.hasNext()) {
				Unit unit = (Unit) it.next();
			    if(i==randomvalue)
			    	return unit;
				i++;
			   }				
				return null;
			}
		}));

	}
	public static Set protectedUnitsSet(CSMethod csMethod)
	{// should be available after conputing the Xedges
		if(csMethod.method_type.equals(CSMethod.RMethod))
		{
			Set protectedSet = new HashSet();
			if(csMethod.getRunit()==null)
				throw new RuntimeException();
			protectedSet.add(csMethod.getRunit());
			return protectedSet;
		}
		else {
			Unit pnode= csMethod.getPunit();
			 Unit cnode =csMethod.getCunit();
		     Pair tmp = new Pair(pnode, cnode);
		    // for safety, I am not sure whetehr the underlying body would be reconstructed
		     SootMethod pcm= Scene.v().getMethod(csMethod.getMsig());
				UnitGraph pcug = new BriefUnitGraph(pcm.getActiveBody());// give u one chance
		     Set protectedSet = protectedSet =protectedSet(pcug, pnode, cnode);;//pc2Protected.get(tmp);
		     if(protectedSet==null)
		    	 throw new RuntimeException();
		     return protectedSet;
		}
	    
	}




}
