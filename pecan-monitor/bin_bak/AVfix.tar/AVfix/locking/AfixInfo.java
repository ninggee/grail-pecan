package AVfix.locking;

import java.util.HashMap;

import soot.Local;
import soot.SootClass;
import soot.SootField;

public class AfixInfo {	
	public static HashMap<Local, SootField> local2global = new HashMap<Local, SootField>();
	public static SootField getGlobalwithLocal(Local local)
	{
		return local2global.get(local);
	}
	public static HashMap<Integer, AfixInfo> bugs2info = new HashMap<Integer, AfixInfo>();
	int bugId =-1;
	SootField globalLockObj = null;
	SootClass mainClass_lockClass =null;
	//HashMap<String, AfixInfoInAMethod> details = new HashMap<String, AfixInfoInAMethod>();//signature2Localbuginfo
	
	public int getBugId() {
		return bugId;
	}
	public void setBugId(int bugId) {
		this.bugId = bugId;
	}
	public SootField getGlobalLockObj() {
		return globalLockObj;
	}
	public void setGlobalLockObj(SootField globalLockObj) {
		this.globalLockObj = globalLockObj;
	}
	public SootClass getMainClass_lockClass() {
		return mainClass_lockClass;
	}
	public void setMainClass_lockClass(SootClass mainClassLockClass) {
		mainClass_lockClass = mainClassLockClass;
	}
//	public HashMap<String, AfixInfoInAMethod> getDetails() {
//		return details;
//	}
//	public void setDetails(HashMap<String, AfixInfoInAMethod> details) {
//		this.details = details;
//	}
//
//	public static AfixInfoInAMethod getLocalInfo(int bugID , String msig)
//	{
//		AfixInfo buginfo  =bugs2info.get(bugID);
//		if(buginfo==null) return null;
//		return buginfo.details.get(msig);
//		
//	}
//	
}
