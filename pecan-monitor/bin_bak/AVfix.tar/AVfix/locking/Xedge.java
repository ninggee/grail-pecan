package AVfix.locking;

import soot.Unit;
import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;

public class Xedge {
	public boolean incoming = false;
	public Unit uniquePoint = null;
	
	
    public boolean isIncoming() {
		return incoming;
	}

	public void setIncoming(boolean incoming) {
		this.incoming = incoming;
	}

	public Unit getUniquePoint() {
		return uniquePoint;
	}

	public void setUniquePoint(Unit uniquePoint) {
		this.uniquePoint = uniquePoint;
	}


	




	protected Unit o1;
    protected Unit o2;


    public Xedge( Unit o1, Unit o2 ) { this.o1 = o1; this.o2 = o2; }
    
   




	public int hashCode() {
    	int o1hash= 0;int o2hash=0;
    	if(o1!=null) o1hash = o1.hashCode();    
    	else {
			throw new RuntimeException();
		}
    	
    	if(o2!=null) o2hash  =o2.hashCode();
    	else {
			throw new RuntimeException();
		}
    	
        return  o1hash + o2hash;
    }
    public boolean equals( Object other ) {
        if( other instanceof Xedge) {
        	Xedge p = (Xedge) other;
            return o1.equals( p.o1 ) && o2.equals( p.o2 );
        } else return false;
    }
    public String toString() {
        return "CrossingEdge "+o1+","+o2;
    }
    public Unit getO1() { return o1; }
    public Unit getO2() { return o2; }





    
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
