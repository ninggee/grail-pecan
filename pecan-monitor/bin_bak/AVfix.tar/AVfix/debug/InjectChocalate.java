package AVfix.debug;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import AVfix.icse.fixing.Properties;

import pldi.locking.CriticalSection;
import pldi.locking.SynchronizedRegionFinder;
import pldi.locking.SynchronizedRegionFlowPair;
import soot.Body;
import soot.Local;
import soot.LongType;
import soot.PatchingChain;
import soot.RefType;
import soot.Scene;
import soot.SootMethod;
import soot.SootMethodRef;
import soot.Unit;
import soot.Value;
import soot.jimple.AssignStmt;
import soot.jimple.EnterMonitorStmt;
import soot.jimple.ExitMonitorStmt;
import soot.jimple.IdentityStmt;
import soot.jimple.Jimple;
import soot.jimple.ReturnStmt;
import soot.jimple.ReturnVoidStmt;
import soot.jimple.Stmt;
import soot.jimple.StringConstant;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.pdg.EnhancedUnitGraph;
import soot.toolkits.scalar.FlowSet;
import soot.util.Chain;

public class InjectChocalate {

	static String observerClass = "AVfix.debug.Chocalate";
	public static  void addLockReport4HealthyCS_ignoreNullExcEnd(SootMethod sm) {
		
		Body b = sm.getActiveBody();
	//	Body clone = (Body)b.clone();
		
		UnitGraph eug = new ExceptionalUnitGraph(
				b);
    	SynchronizedRegionFinder ta = new SynchronizedRegionFinder(
				eug, b, false);
		
		Iterator<Unit> it = b.getUnits().snapshotIterator();
		
	   while (it.hasNext()) {
			Unit unit  = (Unit )it.next();
			if(unit instanceof EnterMonitorStmt)
			{
				addCall4EnterMonitorStmt(sm, (EnterMonitorStmt)unit);
			}
			else if (unit instanceof ExitMonitorStmt) {
				addCall4ExitMonitorStmt(sm,(ExitMonitorStmt)unit);			
			}
			
			
		}
		

	//	sm.setActiveBody(clone);
	//	System.out.println(b.toString());
		
		
		
	
		
	}
	
	public static  void addTimeReport(SootMethod sm) {
		
		Body b = sm.getActiveBody();
	if(!sm.getName().equals("main"))
	{
		throw new RuntimeException("not main");
	}
		
	String toinsertM = "";

    
    PatchingChain<Unit> units = sm.getActiveBody().getUnits();
   
    toinsertM = "startClock";
    SootMethodRef mr = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "()>").makeRef();
    units.insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr)), sm.getActiveBody().getFirstNonIdentityStmt());
    
    toinsertM = "endClock";
    SootMethodRef mr2 = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "()>").makeRef();
    
    Set<Stmt> rets  = new HashSet<Stmt>();
	Iterator<Unit> it = sm.getActiveBody().getUnits().iterator();
	while (it.hasNext()) {
		Unit unit = (Unit) it.next();
		if(unit instanceof ReturnVoidStmt || unit instanceof ReturnStmt)
		{
			rets.add((Stmt) unit );
		}
	}
	for(Stmt ret: rets)
	{
		units.insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr2)), ret);
	}
    
   

		
		
	
		
	}

	public static  void addCall4EnterMonitorStmt(SootMethod sm, EnterMonitorStmt enter) {	
		
		// laod it at the begining
		String toinsertM = "";
		LinkedList args = new LinkedList();		        
        args.addLast(getMethodThreadId(sm));
        args.addLast(enter.getOp());
      //  String localName = ((Local)(cSection.origLock)).getName();
      //  args.addLast(StringConstant.v(localName));
        
        PatchingChain<Unit> units = sm.getActiveBody().getUnits();
       
        toinsertM = "beforeLocking";
        SootMethodRef mr = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "(long,java.lang.Object)>").makeRef();
        units.insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, args)), enter);
        toinsertM = "afterLocking";
        SootMethodRef mr2 = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "(long,java.lang.Object)>").makeRef();
        units.insertAfter(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr2, args)), enter);
       
	}
	
	private static void addCall4ExitMonitorStmt(SootMethod sm, ExitMonitorStmt enter) {
		// TODO Auto-generated method stub
		
		
		// laod it at the begining
		String toinsertM = "";
		LinkedList args = new LinkedList();		        
        args.addLast(getMethodThreadId(sm));
        args.addLast(enter.getOp());
      //  String localName = ((Local)(cSection.origLock)).getName();
      //  args.addLast(StringConstant.v(localName));
        
        
        PatchingChain<Unit> units = sm.getActiveBody().getUnits();
       
        toinsertM = "beforeUnlocking";
        SootMethodRef mr = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "(long,java.lang.Object)>").makeRef();
        units.insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, args)), enter);
        toinsertM = "afterUnlocking";
        SootMethodRef mr2 = Scene.v().getMethod("<" + observerClass + ": void " + toinsertM + "(long,java.lang.Object)>").makeRef();
        units.insertAfter(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr2, args)), enter);
       
	
	}
	
	public static  Local getMethodThreadId(SootMethod sm)
    {
    	Body bb = sm.retrieveActiveBody();
    	//$r0 = staticinvoke <java.lang.Thread: java.lang.Thread currentThread()>() :-1
    	//l3 = virtualinvoke $r0.<java.lang.Thread: long getId()>() :-1
    	// Visitor.methodToThreadIdMap.get(sm)==null can not locate in time the threadId when crossing different runs 
    	
    	Local tid  =locateLocalThreadId(bb);
    	if(tid==null)
    	{
    		tid =addLocalThreadId(bb);
    	}
    	

    	return tid;
    }
    
	private  static Local locateLocalThreadId(Body bb) {
		//the format of the existing added one:
		//$r0 = staticinvoke <java.lang.Thread: java.lang.Thread currentThread()>() :-1
    	//l3 = virtualinvoke $r0.<java.lang.Thread: long getId()>() :-1
    	PatchingChain<Unit> units = bb.getUnits();
		Iterator<Unit> it =units.iterator();
		while (it.hasNext()) {
			Stmt unit = (Stmt) it.next();
			if(unit.containsInvokeExpr()&& unit.toString().contains("<java.lang.Thread: java.lang.Thread currentThread()>"))
			{	// find possible
				Stmt nextOne =(Stmt) units.getSuccOf(unit);
				if(nextOne.containsInvokeExpr() && nextOne.toString().contains("<java.lang.Thread: long getId()>"))
				{
					// got it
					if(nextOne instanceof AssignStmt)
					{
						Local tid = (Local)((AssignStmt) nextOne).getLeftOp();
						if(tid.getType() instanceof LongType)
						{
							return tid;
						}
						else {
							throw new RuntimeException("how can you fail at this place, even" + tid.getType());
						}
					}
				}
					

			}
		}
		
		return null;
	}

	public static Local addLocalThreadId(Body body) {

		Chain units = body.getUnits();
		
		Local tid = Jimple.v().newLocal("tid_"+body.getMethod().getName(), LongType.v());
		Local thread_ = Jimple.v().newLocal("thread_"+body.getMethod().getName(),RefType.v("java.lang.Thread"));
		
		body.getLocals().add(tid);
		//methodToThreadIdMap.put(body.getMethod(),tid);
		// no need any more, it is not useful crossing different runs
		// I design an intelligent method to auto-find the tid
		
		body.getLocals().add(thread_);
		
        String methodSig1 ="<" + "java.lang.Thread" +": java.lang.Thread currentThread()>";
		
        SootMethodRef mr1 = Scene.v().getMethod(methodSig1).makeRef();
       
        Value staticInvoke = Jimple.v().newStaticInvokeExpr(mr1);
        
       	AssignStmt newAssignStmt1 = Jimple.v().newAssignStmt(thread_, staticInvoke);
        
        String methodSig2 ="<" + "java.lang.Thread" +": long getId()>";
		
        SootMethodRef mr2 = Scene.v().getMethod(methodSig2).makeRef();
       
        Value virtualInvoke = Jimple.v().newVirtualInvokeExpr(thread_,mr2);
        
       	AssignStmt newAssignStmt2 = Jimple.v().newAssignStmt(tid, virtualInvoke);
       
       	
       	Stmt insertStmt = getLastIdentityStmt(units);
        if(insertStmt !=null)
            units.insertAfter(newAssignStmt2,insertStmt);
        else
        	units.insertBefore(newAssignStmt2, getFirstNonIdentityStmt(units));

        units.insertBefore(newAssignStmt1, newAssignStmt2); 
        return tid;
	}
	
	private static Stmt getFirstNonIdentityStmt(Chain units)
	{
		Stmt s = (Stmt)units.getFirst();
		while(s instanceof IdentityStmt)
			s = (Stmt) units.getSuccOf(s);
		return s;
		
	}
	private static Stmt getLastIdentityStmt(Chain units)
	{
		Stmt s = getFirstNonIdentityStmt(units);
		return (Stmt)units.getPredOf(s);
		
	}
	

}
