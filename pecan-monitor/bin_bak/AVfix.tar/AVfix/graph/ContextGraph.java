package AVfix.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.jgrapht.graph.DirectedPseudograph;

import popl.petrinet.element.Transition;

import soot.Body;
import soot.SootMethod;
import soot.jimple.Stmt;
import sun.font.TrueTypeFont;
import sun.nio.cs.HistoricallyNamedCharset;

import edu.hkust.clap.datastructure.StackTraceElement_lpxz;
import edu.hkust.clap.organize.CSMethod;
import edu.hkust.clap.organize.CSMethodPair;
import edu.hkust.clap.organize.SaveLoad;
import edu.hkust.clap.organize.SootAgent4Fixing;

import AVdetect.edge.abstractclass.CausalEdge;
import AVdetect.eventnode.abstractclass.CriticalEvent;
import AVdetect.manager.MemoryManager;
import AVdetect.manager.ThreadManager;
import AVfix.edge.CallEdge;
import AVfix.edge.LocalEdge;
import AVfix.edge.ReturnEdge;
import AVfix.edge.abstractclass.ControlEdge;
import AVfix.icse.fixing.ICSEJinFixing;
import AVfix.icse.fixing.ICSEPengFixing;

import AVfix.manager.MethodManager;
import AVfix.node.CommonLocalStatement;
import AVfix.node.EntryStatement;
import AVfix.node.ExitStatement;
import AVfix.node.InvokeBeginStatement;
import AVfix.node.InvokeEndStatement;
import AVfix.node.TStatement;
import AVfix.node.abstractclass.Statement;


public class ContextGraph {

	// additional tags..
	public static ContextGraph _cGraph =null;
	public HashSet<Statement> places = new HashSet<Statement>();
	public HashSet<TStatement> transitions = new HashSet<TStatement>();//after the petrifying, they are not empty 
	
	public HashSet<Statement> getPlaces() {
		return places;
	}
	public void setPlaces(HashSet<Statement> places) {
		this.places = places;
	}
	public HashSet<TStatement> getTransitions() {
		return transitions;
	}
	public void setTransitions(HashSet<TStatement> transitions) {
		this.transitions = transitions;
	}
	//=========================
	
	


	public HashSet<ContextGraphMethod> threadRoots ;
	public HashSet<ContextGraphMethod> getThreadRoots() {
		return threadRoots;
	}
	public void setThreadRoots(HashSet<ContextGraphMethod> threadRoots) {
		this.threadRoots = threadRoots;
	}

	public DirectedPseudograph<Statement, ControlEdge> coreG = null;

	public ContextGraph() {
		coreG = new DirectedPseudograph<Statement, ControlEdge>(
				ControlEdge.class);
		threadRoots = new HashSet<ContextGraphMethod>();
	}
	public static void main(String[] args) {	
		// ICSEJinFixing or ICSEPengFixing, please
//		Object object = SaveLoad.load(SaveLoad.default_filename);
//		 List list  =(List)object;// CSMethodPair List		
//		 System.err.println("set the main class and the analyzedFolder in SootAgent4Fixing");
//		 System.out.println("JIN's:");
//		 ICSEJinFixing.fix(list, null);	
//		 
//		 
//		 System.out.println("===========================================");
//		 System.out.println("Peng's:");
//		
//		Object object2 = SaveLoad.load(SaveLoad.default_filename);
//		 List list2  =(List)object2;// CSMethodPair List		
//		 System.err.println("set the main class and the analyzedFolder in SootAgent4Fixing");
//		 ICSEPengFixing.fix(list2, null);				 
	}
	
   public static int globalI = 0;
   
   public static ContextGraph getContextGraph()
   {
	   if(_cGraph==null)
		   throw new RuntimeException("not ready yet");
	   return _cGraph;
   }
	public static ContextGraph create_get_SingletonCSGraph(List list) {
		if(_cGraph!=null)
			return _cGraph;
		
		_cGraph = new ContextGraph();
		ContextGraph csGraph  =_cGraph;
		
		int count =0;
		int pairID= 0;
		
		for(int i=0;i<list.size();i++)
		{
			
			Object elem = list.get(i);
		//	System.err.println("Iteration:" + i);
			globalI=i;

			CSMethodPair pair = (CSMethodPair)elem;
			CSMethod o1 = pair.getO1();
			CSMethod o2 = pair.getO2();
			
			
			o1.printIt();
			try{
				csGraph.expandCSCG(o1);
			}catch (Exception e) {
				e.printStackTrace();
			}
				
				
	//		 CSGraphVisualizer.visualize(csGraph, "/home/lpxz/eclipse/workspace/pecan/pecan-monitor/tmp/dotfile");
			
			

			o2.printIt();
			try{
				csGraph.expandCSCG(o2);
			}catch (Exception e) {
				e.printStackTrace();			
			}		
			
			
			System.out.println();
		}

		return csGraph;
	}
	private  void expandCSCG(CSMethod o1) {
		List<StackTraceElement_lpxz> stes =o1.getStes();		
		List<StackTraceElement_lpxz> ctxtStack = new ArrayList<StackTraceElement_lpxz>();
		Statement invokeNodeInParent= null;
		for(int i=0; i<= stes.size()-1; i++)
		{
			StackTraceElement_lpxz cur = stes.get(i);
			if(i>=1) // 0 does not have the parent!
			{
				// get the invoke site node
				// CSGraphGen.u2n available now, do not put it after the following "EntryStatement entry =loadOrCreate4Method(cur,ctxtStack);"
				String className = cur.getClassName();
				String mName = cur.getMethodName();
				String filename = cur.getFileName();
				int eleLineNO = cur.getLineNumber();
				String eleLineNo_invoke = cur.getLineNumber_invoke();// provided by the current one, note that, our stackTraceElement is different from jdk one
				// as the ctxt site info is stored by the callee. To make the analysis more convenient and modular.
				StackTraceElement_lpxz secondLast = ctxtStack.get(ctxtStack.size() -1);
//				String secondClass = secondLast.getClassName();
//				String secondMethod = secondLast.getMethodName();	
				
				String secondMsig = secondLast.getmsig();// it is more detailed, including arg
				ContextGraphMethod secondGCS = MethodManager.search4GCSmethod_withFullName(secondMsig, ctxtStack.subList(0, ctxtStack.size() -1));// the secondmethod's ctxt : 0-> (size-2)
				if(secondGCS==null) 
				{
					throw new RuntimeException("it is impossible, must be processed, just now or earlier");
				}
				Stmt hitCS = SootAgent4Fixing.search4CallSiteStmt_reuseGCS(secondGCS, className, mName, filename,eleLineNO, eleLineNo_invoke);	
				
				invokeNodeInParent =secondGCS.getU2S().get(hitCS);				
			}
		
		    // load or create local method for cur
			boolean loaded =false;
//			String fullMethodName = SootAgent.getFullMethodName(cur);
			String cursig = cur.getmsig();
			ContextGraphMethod gcsMethod = MethodManager.search4GCSmethod_withFullName(cursig, ctxtStack);
			if(gcsMethod!=null)
			{			
				loaded= true;
			}
			else {
			
				gcsMethod = ContextGraphGen.formCSMethodLocally(cur, this, ctxtStack);
				MethodManager.register4GCSmethod(cursig, gcsMethod);						
			}		
			EntryStatement entry = gcsMethod.getEntry();
			ExitStatement exit = gcsMethod.getExit();// CSGraphGen.entry2exit.get(entry);
			
			
			
			if(i==0)
			{
				this.getThreadRoots().add(gcsMethod);// do not worry about the duplication, hashset takes care of it. Main may be added
				// multiple times, it is correct.
			}
			if(i>=1)
			{
				if(invokeNodeInParent==null) throw new RuntimeException();
				if(!loaded)// if loaded, no need to remote issues, as nothing needs to be added and constructed
				{
					ContextGraphGen.remoteIssues(this, (CommonLocalStatement)invokeNodeInParent, entry, exit);				
				}
				
			}
			ctxtStack.add(cur);// always updating
		}		
	}
	

	
	public List getLocalSuccs(Object pop) {
		List list = new ArrayList();
		Set<ControlEdge> edges  =this.coreG.outgoingEdgesOf((Statement)pop);
		for(ControlEdge edge : edges)
		{
			if(edge instanceof LocalEdge)
			{ list.add(edge.getTarget());}
		}			
		return list;
	}
	
	public List getAllSuccs(Object pop) {
		List list = new ArrayList();
		Set<ControlEdge> edges  =this.coreG.outgoingEdgesOf((Statement)pop);
		for(ControlEdge edge : edges)
		{
			
			{ list.add(edge.getTarget());}
		}			
		return list;
	}
	
	public List getLocalPrecs(Object pop)
	{
		List list = new ArrayList();
		Set<ControlEdge> edges  =this.coreG.incomingEdgesOf((Statement)pop);
		for(ControlEdge edge : edges)
		{
			if(edge instanceof LocalEdge)
			{ list.add(edge.getSource());}
		}			
		return list;
	}
	
	public List getAllPrecs(Object pop)
	{
		List list = new ArrayList();
		Set<ControlEdge> edges  =this.coreG.incomingEdgesOf((Statement)pop);
		for(ControlEdge edge : edges)
		{
			
			{ list.add(edge.getSource());}
		}			
		return list;
	}

}
