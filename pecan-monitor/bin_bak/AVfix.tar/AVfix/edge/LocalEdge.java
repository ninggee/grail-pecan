package AVfix.edge;

import AVfix.edge.abstractclass.ControlEdge;

public class LocalEdge extends ControlEdge{

}
