package AVfix.node;

import AVfix.node.abstractclass.ConcreteStatement;
import AVfix.node.abstractclass.Statement;

public class CommonLocalStatement extends ConcreteStatement{

}
