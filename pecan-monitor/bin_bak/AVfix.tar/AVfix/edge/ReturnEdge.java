package AVfix.edge;

import AVfix.edge.abstractclass.ControlEdge;

public class ReturnEdge extends ControlEdge{

}
