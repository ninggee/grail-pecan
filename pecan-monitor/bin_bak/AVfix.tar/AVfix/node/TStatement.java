package AVfix.node;

import AVfix.node.abstractclass.Statement;

public class TStatement extends Statement{
	
	

}
