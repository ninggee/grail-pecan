package AVfix.manager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.Match;

import edu.hkust.clap.datastructure.StackTraceElement_lpxz;

import AVfix.graph.ContextGraphMethod;
import AVfix.node.EntryStatement;

public class MethodManager {
	public static HashMap<String, HashSet<ContextGraphMethod>> m2CSMs = new HashMap<String, HashSet<ContextGraphMethod>>();

	public static ContextGraphMethod search4GCSmethod_withFullName(String methodName,
			List<StackTraceElement_lpxz> ctxtStack) {
		HashSet<ContextGraphMethod> gcss =m2CSMs.get(methodName);
		if(gcss==null)
			 return null;
		for(ContextGraphMethod gcs:gcss)
		{
			List<StackTraceElement_lpxz> stes =gcs.getStes();
			if(ctxtsMatch(stes,ctxtStack)){
				//// main has a special ctxt: empty, 
				//the methods with different parameters can not be invoked under the same ctxt!				
				return gcs;
			}
		}
	    
		
	
		
		return null;
	}

	private static boolean ctxtsMatch(List<StackTraceElement_lpxz> stes,
			List<StackTraceElement_lpxz> ctxtStack) {
		if(stes.size() != ctxtStack.size()) return false;
		boolean toret = true;
		for(int i=0; i < stes.size(); i++)
		{
			StackTraceElement_lpxz ste = stes.get(i);
			StackTraceElement_lpxz ste2 = ctxtStack.get(i);
			if(!ste.toString().equals(ste2.toString()))
			{
				toret =false;
			}
		}
		
		return toret;
	}

	public static void register4GCSmethod(String methodName,
			ContextGraphMethod newOne) {
		HashSet<ContextGraphMethod> entrySs =m2CSMs.get(methodName);
		if(entrySs==null)
		{
		  entrySs = new HashSet<ContextGraphMethod>();
		  m2CSMs.put(methodName, entrySs);
		}
		entrySs.add(newOne);
		
	}
	

}
