//package AVfix.locking;
//
//import soot.Local;
//import soot.Unit;
//import soot.jimple.Stmt;
//
//public class AfixInfoInAMethod {
//	public Unit origNonIdStmt = null;// after adding a lot of statements, I do not know which one is the original NONID now.
//	public Unit getOrigNonIdStmt() {
//		return origNonIdStmt;
//	}
//	public void setOrigNonIdStmt(Unit origNonIdStmt) {
//		this.origNonIdStmt = origNonIdStmt;
//	}
//	public  Local localFromGlobal = null;
//	public  Stmt newPrep = null;
//	public  Stmt lastNewGotoEnd= null;
//	public Local getLocalFromGlobal() {
//		return localFromGlobal;
//	}
//	public void setLocalFromGlobal(Local localFromGlobal) {
//		this.localFromGlobal = localFromGlobal;
//	}
//	public Stmt getNewPrep() {
//		return newPrep;
//	}
//	public void setNewPrep(Stmt newPrep) {
//		this.newPrep = newPrep;
//	}
//	public Stmt getLastNewGotoEnd() {
//		return lastNewGotoEnd;
//	}
//	public void setLastNewGotoEnd(Stmt lastNewGotoEnd) {
//		this.lastNewGotoEnd = lastNewGotoEnd;
//	}
//
//}
